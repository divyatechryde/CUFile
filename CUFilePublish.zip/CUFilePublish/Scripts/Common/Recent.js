﻿
function RecentFiles() { }

RecentFiles.prototype = {

    GetAllRecentFiles: function () {
        $.ajax({
            url: 'GetAllUserRecentFiles',
            type: "POST",
            cache: false,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (idata) {
                DisplayDataTables(idata.aaData);
                return;
            },
            error: function (idata) {
                alert(idata.msg);
            }
        });

        function DisplayDataTables(aDataSet) {
            $('#divRecentFiles').html('<table cellpadding="0" cellspacing="0" border="0" class="display" id="myDataTable"></table>');
            $('#myDataTable').dataTable({
                "sPaginationType": "full_numbers",
                "aaData": aDataSet,
                "aoColumns": [
                    {
                        "sTitle": "Name",
                        "sClass": "center",
                        "sName": "ID",
                        "fnRender": function (oObj) {
                            return '<span class="gridFileName">' + oObj.aData[0] + '</span><span class="grid-small-icons"><i onclick="OpenFileSharingBox(this)" id="share-file_' + oObj.aData[5] + '_' + oObj.aData[0] + '" title="Share" class="shareFile icon-link"></i><i title="Download" class="icon-download" onclick="DownloadFile(this)" file-url="' + oObj.aData[5] + '"></i><i title="Delete" class="icon-trash"></i><i title="Sync" class="icon-refresh"></i></span>';
                        }
                    },
                    { "sTitle": "Type", "sClass": "center" },
                    { "sTitle": "Size", "sClass": "center" },
                    { "sTitle": "Location", "sClass": "center" },
                    { "sTitle": "Updated", "sClass": "center" }
                ]
            });
        }
    },

    LoadZeroClipboard: function () {

        var clip = new ZeroClipboard(document.getElementById("btnGetLink"), {
            moviePath: "/Scripts/ZeroClipboard/ZeroClipboard.swf"
        });

        clip.on('load', function (client) {
            //alert("Flash movie loaded and ready.");
        });

        clip.on('noFlash', function (client) {
            alert("Your browser has no Flash.");
        });

        clip.on('wrongFlash', function (client, args) {
            alert("Flash 10.0.0+ is required but you are running Flash " + args.flashVersion.replace(/,/g, "."));
        });

        clip.on('complete', function (client, args) {
            DisplayMessage('Link copied to clipboard', 'success', true);
        });
    },

    SendShareFileEmail: function (fileid, emails, messageText) {
        var invalidEmails = '';
        if ($.trim(emails) != '' && $.trim(fileid) != '') {
            var allEmails = emails.split(',');
            if (allEmails.length > 0) {
                for (var i = 0; i < allEmails.length; i++) {
                    var email = $.trim(allEmails[i]);
                    if (validateEmail(email)) {
                        SendEmail(fileid, email, messageText);
                    }
                    else {
                        invalidEmails += '\'' + allEmails[i] + '\'' + ',';
                    }
                }
                if ($.trim(invalidEmails) != '') {
                    DisplayMessage('Email couldn\'t be sent to <br/>' + invalidEmails, 'error', false);
                }
            }
        }
        else if ($.trim(emails) == '') {
            DisplayMessage('Please provide email', 'error', true);
        }
        else if ($.trim(fileid) == '') {
            DisplayMessage('An error occurred, please try again later.', 'error', true);
        }
    }
};

$(document).ready(function () {
    $('#btnSendFileSharingEmail').click(function () {
        SendFileSharingEmail();
    });

    $('#btnCloseShareBox').click(function () {
        ClearAllSharingFields();
        $('#clipMsg').html('');
    });
});

var fileId
function OpenFileSharingBox(item) {
    var fileName = $(item).attr('id').split('_')[2];
    fileId = $(item).attr('id').split('_')[1];
    $('#shareFileBox').modal('show');
    $('#shareFileBoxHeading').text('Share \'' + fileName + '\'');
    $('#btnGetLink').attr("data-clipboard-text", fileId);
}

function DownloadFile(item) {
    var fileURL = $(item).attr('file-url');
    if ($.trim(fileURL) != '') {
        window.open(fileURL, '_blank');
    }
}

function SendFileSharingEmail() {
    var toEmails = $('#txtEmail').val();
    var textMessage = $('#txtMessage').val();
    recent.SendShareFileEmail(fileId, toEmails, textMessage);
}

function CloseShareBox() {
    $('#shareFileBox').modal('hide')
}

function ClearAllSharingFields() {
    $('#txtEmail').val('');
    $('#txtMessage').val('');
}

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function DisplayMessage(msg, type, removeAfter) {
    var color = 'red';
    if ($.trim(type) == 'success') {
        color = 'green';
    }
    $('#clipMsg').show();
    $('#clipMsg').css('color', color);
    $('#clipMsg').html(msg);
    if (removeAfter) {
        setTimeout('$(\'#clipMsg\').fadeOut();', 2000);
    }
}

function SendEmail(fileid, email, messageText) {
    $.ajax({
        url: 'SendShareFileEmail',
        type: "POST",
        data: { fileId: fileid, toEmail: email, message: messageText, fileType: 'recent' },
        cache: false,
        dataType: "json",
        success: function (idata) {
            if (idata.result == 'success') {
                CloseShareBox();
                ClearAllSharingFields();
            }
            return;
        },
        error: function (idata) {
            alert(idata.msg);
        }
    });
}