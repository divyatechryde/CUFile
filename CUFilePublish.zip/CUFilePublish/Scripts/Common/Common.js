﻿function Common()
{ }

Attr.prototype.url = "";

/* Use for search */
Attr.prototype.start = 0;
Attr.prototype.fileloopCounter = 0;
Attr.prototype.folderloopCounter = 0;
Attr.prototype.totalRecords = 0;
Attr.prototype.data = "";
Attr.prototype.searchStatus = "";

Attr.prototype.focusStatus = "False";

Common.prototype = {

    /* Check Password Strength */
    CheckPasswordStrength: function (password) {
        var noofchar = /^.*(?=.{6,}).*$/;
        var checkspace = /\s/;
        var best = /^.*(?=.{6,})(?=.*[A-Z])(?=.*[\d])(?=.*[\W]).*$/;
        var strong = /^[a-zA-Z\d\W_]*(?=[a-zA-Z\d\W_]{6,})(((?=[a-zA-Z\d\W_]*[A-Z])(?=[a-zA-Z\d\W_]*[\d]))|((?=[a-zA-Z\d\W_]*[A-Z])(?=[a-zA-Z\d\W_]*[\W_]))|((?=[a-zA-Z\d\W_]*[\d])(?=[a-zA-Z\d\W_]*[\W_])))[a-zA-Z\d\W_]*$/;
        var weak = /^[a-zA-Z\d\W_]*(?=[a-zA-Z\d\W_]{6,})(?=[a-zA-Z\d\W_]*[A-Z]|[a-zA-Z\d\W_]*[\d]|[a-zA-Z\d\W_]*[\W_])[a-zA-Z\d\W_]*$/;
        var bad = /^((^[a-z]{6,}$)|(^[A-Z]{6,}$)|(^[\d]{6,}$)|(^[\W_]{6,}$))$/;

        if (!password) {
            $("#pStrength").html("<div class=\"password-meter\"><div class=\"password-meter-message password-meter-message-too-short\">Password cannot empty</div> " +
                "<div class=\"password-meter-bg\">" +
                    "<div class=\"password-meter-bar password-meter-too-short\"></div>" +
                "</div></div>");
            return "red";
        }
        else if (true == checkspace.test(password)) {
            $("#pStrength").html("<div class=\"password-meter\"><div class=\"password-meter-message password-meter-message-too-short\">Spaces are not allowed</div> " +
                "<div class=\"password-meter-bg\">" +
                    "<div class=\"password-meter-bar password-meter-too-short\"></div>" +
                "</div></div>");
            return "red";
        }
        else if (false == noofchar.test(password)) {
            $("#pStrength").html("<div class=\"password-meter\"><div class=\"password-meter-message password-meter-message-too-short\">To short</div> " +
                "<div class=\"password-meter-bg\">" +
                    "<div class=\"password-meter-bar password-meter-too-short\"></div>" +
                "</div></div>");
            return "red";
        }
        else if (best.test(password)) {
            $("#pStrength").html("<div class=\"password-meter\">" +
		    "<div class=\"password-meter-message password-meter-message-good\">Best</div>" +
		    "<div class=\"password-meter-bg\">" +
			"<div class=\"password-meter-bar password-meter-good\"></div>" +
	    	"</div>" +
        	"</div>");
            return "green";
        }
        else if (strong.test(password)) {
            $("#pStrength").html("<div class=\"password-meter\">" +
		    "<div class=\"password-meter-message password-meter-message-strong\">Strong</div>" +
		    "<div class=\"password-meter-bg\">" +
			"<div class=\"password-meter-bar password-meter-strong\"></div>" +
	    	"</div>" +
        	"</div>");
            return "brown";
        }
        else if (weak.test(password) == true && bad.test(password) == false) {
            $("#pStrength").html("<div class=\"password-meter\">" +
		    "<div class=\"password-meter-message password-meter-message-weak\">Weak</div>" +
		    "<div class=\"password-meter-bg\">" +
			"<div class=\"password-meter-bar password-meter-weak\"></div>" +
	    	"</div>" +
        	"</div>");
            return "orange";
        }
        else if (bad.test(password)) {
            $("#pStrength").html("<div class=\"password-meter\">" +
		    "<div class=\"password-meter-message password-meter-message-weak\">Very weak</div>" +
		    "<div class=\"password-meter-bg\">" +
			"<div class=\"password-meter-bar password-meter-weak\"></div>" +
	    	"</div>" +
        	"</div>");
            return "red";
        }
    },

    /* Common ready function */
    ReadyFunctions: function (url) {
        var directoryManager = new DirectoryManager();
        var self = this;
        Attr.prototype.url = url;
        directoryManager.SortByFileName();
        self.FilesIcon();
        directoryManager.ReadyFunctions();
        directoryManager.LeftNav();
        directoryManager.pageUrl = url;
        directoryManager.ContainerMenuNav_click(url);
        directoryManager.GetSubFolderPaged(url);
        // Add on 25 aug 2015
        //directoryManager.TopMenuButtonSetting();
    },

    /* Ajax Call from directoryManager */
    AjaxCall: function (url, data, requestType, dataType, contentType, successCallbackMethodName, errorCallbackMethodName) {
        var self = this;
        $.ajax({
            url: url,
            type: requestType,
            data: data,
            dataType: dataType,
            contentType: contentType,
            success: function (data) {
                self[successCallbackMethodName](data);
            },
            error: function (data) {
                $('#loadingRecords').html(data);
            }
        });
    },

    AjaxCallObj: function (url, data, requestType, dataType, contentType, successCallbackMethodName, errorCallbackMethodName, obj) {
        var self = this;
        var common = new Common();
        $.ajax({
            url: url,
            type: requestType,
            data: data,
            dataType: dataType,
            contentType: contentType,
            success: function (data) {
                obj[successCallbackMethodName](data);
            },
            error: function (data) {
                obj[errorCallbackMethodName](data);
            }
        });
    },

    /* BlockUI for ajax */
    AjaxStart: function () {
        $('#data-list').bind('ajaxStart', function () {
            var timer = $("#hfTimer").val();
            if (timer != "1") {
                NProgress.start();
            }
        }).bind('ajaxStop', function () {
            NProgress.done();
            $("#hfTimer").val("");
        });


    },

    /* Call when Folder And Files By Timer. */
    DirectoryManager_GetFolderAndFilesByTimer_OnSuccess: function (data) {

        //alert("In DirectoryManager_GetFolderAndFilesByTimer_OnSuccess");
        //alert(data);
        $('#btnLinkFiles').removeAttr("disabled");
        var directoryManager = new DirectoryManager();
        var self = this;

        var newFolders = "";
        var newFiles = "";
        var updateFolders = "";
        var updateFiles = "";
        var datareturn = data;
        var singleFileDelete = "False";
        //console.log($datareturn);
        if ($.trim(datareturn) != "") {
            $(data).filter("tr").each(function () {
                var tr = "";
                tr = $(this).prop('outerHTML');
                //console.log('tr in fadeout html ' + tr);
                var trClass = $(this).filter("tr").attr("class");
                //console.log('trClass in fadeout html ' + trClass);
                if (trClass == "deletedFileId" || trClass == "deletedFolderId") {
                    console.log('In Fadeout ' + trClass);
                    var id = "";
                    id = $(this).find("span").text();
                    //console.log('In Fadeout ' + id);                   
                    //alert(curLength);
                    var htmlId = "#loadingRecords > tr#" + id;
                    //console.log('Elem ' + htmlId);
                    if ($(htmlId).length > 0) {
                        singleFileDelete = "True";
                    }
                    $(htmlId).fadeOut(2000, function () {
                        $(this).remove();
                        
                    });
                }
            });
            console.log('=============================================');
            var curLength = $("#loadingRecords tr").length;
            // Qasim 25-Nov-2015 // Only Single file in Records. And delete that file.
            console.log(curLength);
            console.log(singleFileDelete);
            if (curLength <= 1 && singleFileDelete == "True") {
                //var trClass = $(this).filter("tr").attr("class");
                //if ($("#loadingRecords tr").hasClass("NoFileAvailable")) {
                console.log("in curLength tr " + curLength);
                $('#loadingRecords').append('<tr class="NoFileAvailable">' +
                '<td colspan="7" class="text-center">' +
                    '<div class="col-lg-12 col-md-12 col-sm-12">' +
                        'No files available.' +
                    '</div>' +
                    '</td>' +
                '</tr>"');
                //}
            }

            $(data).filter("tr").each(function () {
                var tr = "";
                tr = $(this).prop('outerHTML');
                //console.log('tr in Append html ' + tr);
                var trClass = $(this).filter("tr").attr("class");
                var id = $(this).filter("tr").attr("id");// Nov-24-2015
                //console.log('trClass in Append html ' + trClass);

                if (trClass == "File" || trClass == "Folder") {
                    //if (trClass.indexOf("File") != -1 || trClass.indexOf("Folder") != -1) {
                    console.log('In append ' + trClass);
                    if ($('#loadingRecords > tr').hasClass("File") || $('#loadingRecords > tr').hasClass("Folder")) {
                        console.log('In append hasClass ' + trClass);
                        $('#loadingRecords > tr.' + trClass + ':first').before(tr, callbackforold(id));
                    }
                    else {
                        console.log('Aho Aho Aho');
                        $('#loadingRecords > tr').remove();
                        $('#loadingRecords').append(tr);
                    }
                }
            });

            
        }
        else {
        }

        function callbackforold(id) {
            $('#loadingRecords > tr#' + id).hide(function () {
                $(this).fadeIn(3000);
            });
        };

        // Old Pogo ha ya :( // 24-Nov-2015
        //function callback1(trClass) {
        //    $('#loadingRecords > tr.' + trClass + ':first').hide(function () {
        //        $(this).fadeIn(3000);
        //    });
        //};

        self.FilesIcon();
        //self.EmptySearchValues();
        directoryManager.ReadyFunctions();
        directoryManager.SortByFileName();
        directoryManager.imageViewer();
        directoryManager.RightClickMenu(Attr.prototype.url);
        $("#hfTimerStatus").val("False");
        //console.log("DirectoryManager_GetFolderAndFilesByTimer_OnSuccess " + $("#hfTimerStatus").val());
    },

    DirectoryManager_GetFolderAndFilesByTimer_OnError: function (data) {
        console.log(data);
    },

    /* Call when first time page load. */
    DirectoryManager_GetPaged_OnSuccess: function (data) {
        var directoryManager = new DirectoryManager();
        var self = this;
        $('#loadingRecords tr:last').before(data);
        if ($(data + ' <tr>').length < 200) {
            $('#loadingRecords tr:last').addClass("hide");
        }


        $("#div-btn-top-group").show();
        $("#div-recent-file-status").hide();

        self.FilesIcon();
        self.EmptySearchValues();
        directoryManager.ReadyFunctions();
        directoryManager.SortByFileName();
        directoryManager.imageViewer();
    },

    /* Call when first time page load. */
    DirectoryManager_GetAllRecentFiles_OnSuccess: function (data) {
        var directoryManager = new DirectoryManager(); var self = this;
        $('#loadingRecords').html(data);

        var status = $("#allrecentfolderstatus").attr("data-allrecentfolderstatus");
        //alert(status);
        if (status == "True") {
            $("#div-recent-file-status a").html("Off");
            $("#div-recent-file-status a").removeClass("on");
            $("#div-recent-file-status a").addClass("off");
        }
        else {
            $("#div-recent-file-status a").html("On");
            $("#div-recent-file-status a").removeClass("off");
            $("#div-recent-file-status a").addClass("on");
        }
        $("#div-btn-top-group").hide();
        $("#div-recent-file-status").show();

        self.EmptySearchValues();
        self.ReadyFunctions(Attr.prototype.url);
        //directoryManager.GetAllRecentFiles(Attr.prototype.url);
        directoryManager.SortByFileName();
        directoryManager.imageViewer();
    },

    RecentFileSyncON_OnSuccess: function (data) {
        if (data) {
            $("#div-recent-file-status a").html("Off");
            $("#div-recent-file-status a").removeClass("on");
            $("#div-recent-file-status a").addClass("off");
        }
    },

    RecentFileSyncON_OnError: function (data) {
        var directoryManager = new DirectoryManager();
        var self = this;
        alert("Error RecentFileSyncON " + data);
    },


    RecentFileSyncOff_OnSuccess: function (data) {
        if (data) {
            $("#div-recent-file-status a").html("On");
            $("#div-recent-file-status a").removeClass("off");
            $("#div-recent-file-status a").addClass("on");
        }
    },

    RecentFileSyncOff_OnError: function (data) {
        var directoryManager = new DirectoryManager();
        var self = this;
        alert("Error RecentFileSyncOff " + data);
    },


    /* Call from Home click of container Menu. */
    DirectoryManager_GetPagedHome_OnSuccess: function (data) {
        var self = this;
        var directoryManager = new DirectoryManager();
        $('#containerDatalist').replaceWith(data);


        $("#div-btn-top-group").show();
        $("#div-recent-file-status").hide();

        $(".seeMore_Home").click(function () {
            directoryManager.GetPaged_OnSeeMoreClick(Attr.prototype.url)
        });
        self.FilesIcon();
        self.EmptySearchValues();
        self.ReadyFunctions(Attr.prototype.url);
        directoryManager.ReadyFunctions();
        directoryManager.imageViewer();
    },

    /* Call from click on Sub Folders of data lists. */
    DirectoryManager_GetSubFolderPaged_OnSuccess: function (data) {
        var self = this;
        var directoryManager = new DirectoryManager();
        $('#loadingRecords').html(data);
        //$('#loadingRecords tr:last').after("<tr><td colspan='7' ><a class='seeMore_SubFolder' >See More...</a></td></tr>");
        $(".seeMore_SubFolder").click(function () {
            directoryManager.GetSubFolder_SeeMore(Attr.prototype.url)
        });
        directoryManager.ReadyFunctions();
        directoryManager.imageViewer();
        self.ReadyFunctions(Attr.prototype.url);
        self.EmptySearchValues();
    },

    alert_message: function (className, message) {
        $('#alert-message').removeClass("hidden");
        $('#alert-message').addClass(className);
        $('#alert-message-span').text(message);
        $('#alert-message').fadeIn('slow', function () {
            $(this).delay(3000).fadeOut('slow');
        });
    },

    RenameFile_OnSuccess: function (data) {
        $('#RenameFileModal').modal('hide');
        //this.alert_message("alert-success", "File Rename");
        toastr.success("File rename successfully.", "Success");
    },

    RenameFile_OnError: function (data) {
        $('#RenameFileModal').modal('hide');
        //this.alert_message("alert-success", "File Rename");
        toastr.error("An error occurred please try again later.", "Error");
    },

    DeleteFile_OnSuccess: function (data) {
        $('#DeleteFileModal').modal('hide');
        //this.alert_message("alert-success", "File Deleted");
        toastr.success("File Deleted successfully.", "Success");
    },

    DeleteFile_OnError: function (data) {
        $('#DeleteFileModal').modal('hide');
        //this.alert_message("alert-success", "An error occurred please try again later.");
        toastr.error("An error occurred please try again later.", "Error");
    },

    UndoFile_OnSuccess: function (data) {
        $(".breadcrumb li a").trigger("click");
        toastr.success("File undo successfully.", "Success");
        // This is old way. I add new on 20 august 2015. 
        //$('#alert-message').removeClass("hidden");
        //$('#alert-message').addClass("alert-success");
        //$('#alert-message-span').text("File Undo")
        //$('#alert-message').fadeIn('slow', function () {
        //    $(this).delay(5000).fadeOut('slow');
        //});
    },

    UndoFile_OnError: function (data) {
        $(".breadcrumb li a").trigger("click");
        toastr.error("An error occurred please try again later.", "Error");
    },

    /* Call from search which have a small list of data. */
    DirectoryManager_GetSmallSearch_OnSuccess: function (data) {
        var self = this;
        var directoryManager = new DirectoryManager();
        $('#loadingRecords').html("").html(data);
        directoryManager.ReadyFunctions();
        self.ReadyFunctions(Attr.prototype.url);
        directoryManager.imageViewer();
    },

    /* Call from Top Bar Deleted Button. */
    DirectoryManager_GetDeletedFiles_OnSuccess: function (data) {
        var self = this;
        var directoryManager = new DirectoryManager();
        $('#loadingRecords').html(data);
        directoryManager.ReadyFunctions();
        self.ReadyFunctions(Attr.prototype.url);
    },

    /* Call for search data lists. */
    GetSearch_Opration: function (data) {
        var self = this; var directoryManager = new DirectoryManager();
        Attr.prototype.data = data;

        var totalRecords = data.TotalFiles + data.TotalFolders;
        Attr.prototype.totalRecords = totalRecords;
        var jsonArr = [];

        if (Attr.prototype.start < totalRecords && totalRecords > 500) {

            // If no more files in that search. Folder HTML true.
            var FolderFile = "";

            console.log("Total Folders " + data.TotalFolders + " && Folder Loop " + Attr.prototype.folderloopCounter);

            if (data.TotalFolders > 0 && Attr.prototype.folderloopCounter < data.TotalFolders) {
                FolderFile = 1;
                for (var i = 0; i < 100; i++) {
                    if (Attr.prototype.start < data.TotalFolders) {
                        //console.log("folderloopCounter " + Attr.prototype.folderloopCounter + " start " + Attr.prototype.start);
                        var modifyDate = ToJavaScriptDate(data.SyncedFolder.Folders[Attr.prototype.folderloopCounter].ModifyDate);
                        jsonArr.push({
                            SyncFolderId: data.SyncedFolder.Folders[Attr.prototype.folderloopCounter].SyncFolderId,
                            FolderName: data.SyncedFolder.Folders[Attr.prototype.folderloopCounter].FolderName,
                            TotalSize: data.SyncedFolder.Folders[Attr.prototype.folderloopCounter].TotalSize,
                            ModifyDate: modifyDate,
                            FolderFile: FolderFile,
                        });
                        Attr.prototype.folderloopCounter++;
                        Attr.prototype.start++;
                    }
                    else {
                        if (data.TotalFiles == 0)
                        { $('#loadingRecords tr:last').hide(); }
                        //Attr.prototype.start++;
                        break;
                    }
                }
            }
            else {
                console.log("Else " + Attr.prototype.start);
                for (var i = 0; i < 100; i++) {
                    if (Attr.prototype.start < (totalRecords - 1)) {
                        FolderFile = 0;
                        var modifyDate = ToJavaScriptDate(data.SyncedFolder.FolderFiles[Attr.prototype.fileloopCounter].ModifyDate);
                        //console.log("fileloopCounter " + Attr.prototype.fileloopCounter + " start " + Attr.prototype.start);
                        jsonArr.push({
                            FileName: data.SyncedFolder.FolderFiles[Attr.prototype.fileloopCounter].FileName,
                            FileExtention: data.SyncedFolder.FolderFiles[Attr.prototype.fileloopCounter].FileExtention,
                            FileSize: data.SyncedFolder.FolderFiles[Attr.prototype.fileloopCounter].FileSize,
                            ModifyDate: modifyDate,
                            FolderFile: FolderFile,
                        });
                        Attr.prototype.fileloopCounter++;
                        Attr.prototype.start++;
                    }
                    else {
                        $('#loadingRecords tr:last').hide();
                        break;
                    }

                }
            }
            self.AjaxCall(Attr.prototype.url + "/_SearchContainerItems", JSON.stringify(jsonArr),
                             "POST", "json", "application/json",
                             "GetSearch_HTML", "");
        }
        else {

            common.AjaxCall(Attr.prototype.url + "/_SmallSearchContainerItems", "",
                      "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                      "DirectoryManager_GetSmallSearch_OnSuccess", "");

        }
        function ToJavaScriptDate(value) {
            var pattern = /Date\(([^)]+)\)/;
            var results = pattern.exec(value);
            var dt = new Date(parseFloat(results[1]));
            return (dt.getMonth() + 1) + "/" + dt.getDate() + "/" + dt.getFullYear();
        }
    },

    /* Call from GetSearch_Opration. */
    GetSearch_HTML: function (data) {
        var self = this;
        var directoryManager = new DirectoryManager();
        var startValue = Attr.prototype.start - 1;
        if (Attr.prototype.totalRecords > 500) {
            if (startValue <= 100) {
                $('#loadingRecords').html("").html(data);
                $('#loadingRecords tr:last').after("<tr ><td  colspan='5' ><a class='seeMore_Home'>See More...</a></td></tr>");
                $(".seeMore").click(function () {
                    self.GetSearch_Opration(Attr.prototype.data)
                });
            }
            else {
                Attr.prototype.searchStatus = "old";
                $('#loadingRecords tr:last').before(data);
            }
            directoryManager.ReadyFunctions();
            directoryManager.imageViewer();
            self.FilesIcon();
            directoryManager.SortByFileName();
        }
    },

    /* Default Search Settings.*/
    DefaultSearchSetting: function (status) {
        if (status == "new") {
            Attr.prototype.start = 1;
            Attr.prototype.fileloopCounter = 1;
            Attr.prototype.folderloopCounter = 1;
            Attr.prototype.totalRecords = 0;
            Attr.prototype.data = "";
            Attr.prototype.searchStatus = status;
        }

    },

    /* Use for delete the recent serach value*/
    EmptySearchValues: function () {
        Attr.prototype.start = 1;
        Attr.prototype.end = 10;
        $("#serachTextBox").val('');
    },

    /* Use for making file icons*/
    FilesIcon: function () {
        $(".FileExtention").each(function (index, el) {
            var fileType = $(this).attr('data-id');
            var returnType = FileType($(this).attr('data-id')).toLowerCase();

            if (fileType == "Folder") {
                $(this).addClass(returnType + "  navBarIconColor pr15");
            }
            else if (returnType == "docx" || returnType == "doc") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-word-o bg-word");
                $(this).text(returnType);
            }
            else if (returnType == "xlsx" || returnType == "xls") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-excel-o bg-excel");
                $(this).text(returnType);
            }
            else if (returnType == "pdf") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-pdf-o bg-pdf");
                $(this).text(returnType);
            }
            else if (returnType == "jpeg" || returnType == "jpg" || returnType == "png" || returnType == "gif" || returnType == "bitmap") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-image bg-image");
                $(this).text(returnType);
            }
            else if (returnType == "txt") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-text-o bg-file");
                $(this).text(returnType);
            }
            else if (returnType == "rar") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-archive-o bg-rar");
                $(this).text(returnType);
            }
            else if (returnType == "zip") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-zip-o bg-zip");
                $(this).text(returnType);
            }
            else if (returnType == "mp3" || returnType == "wav" || returnType == "3gp" || returnType == "m4a") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-audio-o bg-audio");
                $(this).text(returnType);
            }
            else if (returnType == "mp4" || returnType == "mkv" || returnType == "avi" || returnType == "mov" || returnType == "webm" || returnType == "flv" || returnType == "ogv" || returnType == "ogg" || returnType == "wmv" || returnType == "mpg" || returnType == "mpeg" || returnType == "m4v" || returnType == "3gp") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-video-o bg-video");
                $(this).text(returnType);
            }
            else if (returnType == "css" || returnType == "js" || returnType == "php" || returnType == "cs" || returnType == "cshtml" || returnType == "html" || returnType == "ashx" || returnType == "asax" || returnType == "config" || returnType == "aspx" || returnType == "aspx.cs" || returnType == "htm") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-code-o bg-code");
                $(this).text(returnType);
            }
            else if (returnType == "psd") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file-image-o bg-psd");
                $(this).text(returnType);
            }
            else if (returnType == "ppt" || returnType == "pptx") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-pie-chart bg-powerpoint");
                $(this).text(returnType);
            }
            else if (returnType == "exe" || returnType == "msi" || returnType == "pkg" || returnType == "mpkg") {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-gears bg-setup");
                $(this).text(returnType);
            }
            else {
                $("#liFile-" + $(this).attr('data-file-id')).addClass("fa fa-file bg-file");
                $(this).text(returnType);
            }
        });
        function FileType(filetype) {
            if (filetype != null) {

                if (filetype == "Folder") { return "glyphicon-folder-close"; }
                else {
                    var val = filetype.substring(1);
                    return val;
                }
            }
            else {
                return "0";
            }
        }
    },

    /* Call from search which have a small list of data. */
    GetSocialContacts_OnSuccess: function (data) {
        var directoryManager = new DirectoryManager();
        //because multiple event bind on focus
        //$("input#searchSocialContact").unbind();
        ///////////////=============== Auto Complete Contacts============/////////////////
        var myArr = [];
        $.ajax({
            type: "GET",
            url: "Resources/UserContacts/" + data + ".xml", // change to full path of file on server
            dataType: "xml",
            success: directoryManager.ActiveButtonsAfterFetch,
            cache: false,
            failure: function (data) {
                console.log("XML File could not be found");
            }
        });

        function split(val) {
            return val.split(/,\s*/);
        }

        function extractLast(term) {
            return split(term).pop();
        }

        function setupAC() {
            $("input#searchSocialContact").autocomplete({
                minLength: 0,
                source: function (request, response) {
                    response($.ui.autocomplete.filter(
                      myArr, extractLast(request.term)));
                },
                focus: function () {
                    return false;
                },
                select: function (event, ui) {
                    var terms = split(this.value);
                    terms.pop(); // remove the current input                    
                    terms.push(ui.item.value);// add the selected item                    
                    terms.push("");// add placeholder to get the comma-and-space at the end
                    this.value = terms.join(",");
                    return false;
                }
            });
        }

        if (Attr.prototype.focusStatus == "False") {
            Attr.prototype.focusStatus = "True";
            $("input#searchSocialContact").focus(function () {
                myArr = [];
                $.ajax({
                    type: "GET",
                    url: "Resources/UserContacts/" + data + ".xml", // change to full path of file on server
                    dataType: "xml",
                    success: parseXmlONfocus,
                    complete: setupAC,
                    cache: false,
                    failure: function (data) {
                        console.log("XML File could not be found");
                    }
                });
            });
        }

        function parseXmlONfocus(xml) {
            // Call for apply style on connected social networks
            directoryManager.ActiveButtonsAfterFetch(xml);
            $(xml).find("Email").each(function () {
                myArr.push($(this).attr("label"));
            });
        }

        ///////////////=============== End Auto Complete Contacts ============/////////////////
    },

    /* Call from Top Bar Deleted Button. */
    GetSocialContacts_OnError: function (data) {
        toastr.error("Error in get social contacts.");
    },

    /* Call popup sharefile. */
    SendShareFileEmail_OnSuccess: function (data) {
        if (data == "True") {
            toastr.success("Email sent successfully.");
        }

        else {
            toastr.error("Error in send email. Try again later.");
        }
    },

    /* Call popup sharefile. */
    SendShareFileEmail_OnError: function (data) {
        if (data == "True") {
            toastr.success("Email sent successfully.");
        }

        else {
            toastr.error("Error in send email. Try again later.");
        }
    },

    /* Call from Top Bar Buttons. */
    GetSocialContactsForDisconnect_OnSuccess: function (data) {
        defaultStyle();
        $.ajax({
            type: "GET",
            url: "Resources/UserContacts/" + data + ".xml", // change to full path of file on server
            dataType: "xml",
            success: parseXml,
            complete: "",
            cache: false,
            failure: function (data) {
                console.log("XML File could not be found");
            }
        });

        function parseXml(xml) {
            //defaultStyle();
            checkStatus(xml, "Google");
            checkStatus(xml, "Yahoo");
            checkStatus(xml, "Outlook");
        }

        function checkStatus(xml, root) {
            $(xml).find(root).each(function () {
                $(this).find("Status").each(function () {
                    var status = $(this).attr("label");
                    if (status == "True" && root == "Google") {
                        $("#btnStaticGoogle").addClass("fa-google-color");
                        $("#btnDisconnectGoogle").show();
                        $("#spanNotConnectedGoogle").hide();
                    }
                    else if (status == "True" && root == "Yahoo") {
                        $("#btnStaticYahoo").addClass("fa-yahoo-color");
                        $("#btnDisconnectYahoo").show();
                        $("#spanNotConnectedYahoo").hide();
                    }
                    else if (status == "True" && root == "Outlook") {
                        $("#btnStaticWindows").addClass("fa-windows-color");
                        $("#btnDisconnectOutlook").show();
                        $("#spanNotConnectedWindows").hide();
                    }

                });
            });
        }

        function defaultStyle() {
            $("#btnDisconnectGoogle").hide();
            $("#spanNotConnectedGoogle").show();
            $("#btnStaticGoogle").removeClass("fa-google-color");
            $("#btnDisconnectYahoo").hide();
            $("#spanNotConnectedYahoo").show();
            $("#btnStaticYahoo").removeClass("fa-yahoo-color");
            $("#btnDisconnectOutlook").hide();
            $("#spanNotConnectedWindows").show();
            $("#btnStaticWindows").removeClass("fa-windows-color");
        }
    },

    /* Call from Top Bar Buttons. */
    GetSocialContactsForDisconnect_OnError: function (data) {
        toastr.error("Error in get social contacts.");
    },

    Disconnect_OnSuccess: function (data) {
        if (data == "Success") {
            toastr.success("Disconnect successfully.");
        }

        else {
            toastr.error("Error in disconnect. Try again later.");
        }
    },

    Disconnect_OnError: function (data) {
        if (data == "Error") {
            toastr.error("Error in disconnect. Try again later.");
        }
    },

    Download_OnSuccess: function (data) {
        console.log("Download_OnSuccess");
    },

    Download_OnError: function (data) {
        console.log("Download_OnError");
    },

    GetEncryptCusFileIdAndUserID_OnSuccess: function (data) {
        var directoryManager = new DirectoryManager();
        //console.log(data);
        if (data == "BandwidthExceeded")
            toastr.error("Current bandwidth limit exceeded.", "Error");
        else if (data != "" && data != null) {
            directoryManager.SetFileLinkInTextBox(data);
        }
        else {
            toastr.error("Error in get file id. Try again later.");
        }
    },

    GetEncryptCusFileIdAndUserID_OnError: function (data) {
        console.log(data);
    },

    GetEncryptCusFileIdAndUserIDByContextMenu_OnSuccess: function (data) {
        var directoryManager = new DirectoryManager();
        if (data != "" && data != null) {
            directoryManager.SetFileDownloadByContextMenu(data);
            directoryManager.CallFileDownloadByContextMenu();
        }
        else {
            toastr.error("Error in get file id. Try again later.");
        }
    },

    GetEncryptCusFileIdAndUserIDByContextMenu_OnError: function (data) {
        console.log(data);
    },

    GetShareFileURL_OnSuccess: function (data) {
        console.log(data);
    },

    GetShareFileURL_OnError: function (data) {
        console.log("GetShareFileURL_OnError");
    },

    /*Get All Users Files. */
    DirectoryManager_GetAllUserFiles_OnSuccess: function (data) {
        var directoryManager = new DirectoryManager(); var self = this;
        $('#loadingRecords').html(data);

        $("#div-btn-top-group").show();
        $("#div-recent-file-status").hide();

        self.EmptySearchValues();
        self.ReadyFunctions(Attr.prototype.url);
        directoryManager.SortByFileName();
        directoryManager.imageViewer();
        self.FilesIcon();

    },

    /*Get All Users Files error. */
    DirectoryManager_GetAllErrorFiles_OnError: function (data) {
        $('#loadingRecords').html(data);
        self.EmptySearchValues();
        self.ReadyFunctions(Attr.prototype.url);
        directoryManager.SortByFileName();
        directoryManager.imageViewer();
    },

    /*Get All Share Files. */
    DirectoryManager_GetAllShareFiles_OnSuccess: function (data) {
        var directoryManager = new DirectoryManager(); var self = this;
        $('#loadingRecords').html(data);


        $("#div-btn-top-group").show();
        $("#div-recent-file-status").hide();

        self.EmptySearchValues();
        self.ReadyFunctions(Attr.prototype.url);
        directoryManager.SortByFileName();
        directoryManager.imageViewer();
    },

}
