﻿//$('#btnYesDeleteFile').click(function (url) {
//    alert("in");
//    alert(url);
//    if (Attr.prototype.currentFolderOrFileId != 0) {
//        alert("in if");
//        common.AjaxCall(url + "/_DeleteFiles", "folderOrFileId=" + Attr.prototype.currentFolderOrFileId,
//    "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
//    "DeleteFile_OnSuccess", "");
//    }
//});

//$('#btnSaveRenameFile').click(function (url) {
//    alert(url);
//    if ($('#txtRenameFile').val() == '') {
//        $(".alert-danger").removeClass("hidden");
//        window.setTimeout(function () { $(".alert-danger").addClass("hidden"); }, 2000);
//    }
//    else {
//        var val = '';
//        // Folder id is undefined
//        if ($('#txtRenameFile').data('id') === undefined) {
//            val = $('#txtRenameFile').val();
//        }
//        else {
//            val = $('#txtRenameFile').val() + "." + $('#txtRenameFile').data('id');
//        }

//        common.AjaxCall(url + "/_RenameFile", "folderOrFileId=" + Attr.prototype.currentFolderOrFileId + "&folderOrFileName=" + val,
//    "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
//    "RenameFile_OnSuccess", "");
//    }
//});



//$("#container").droppable({
//    drop: function (event, ui) {
//        $(this)
//        .addClass("ui-state-highlight")
//        .find("p")
//        .html("Dropped!");
//    }
//});


RightClickMenu: function (url) {
    var self = this;
    (function ($, window) {
        $.fn.contextMenu = function (settings) {
            return this.each(function () {
                // Open context menu
                $(this).on("contextmenu", function (e) {
                    //open menu 
                    // Final
                    var className = e.target.parentElement.className;
                    Attr.prototype.isFolderOrFile = className;
                    //alert(className);
                    if (className == "File" || className.indexOf('File') >= 0) {
                        $("#contextMenu li:nth-child(2)").removeClass("hidden");
                    }
                    if (className.indexOf('Folder') >= 0 || className.indexOf('Deleted') >= 0) {
                        $("#contextMenu li:nth-child(2)").addClass("hidden");
                    }
                    $(settings.menuSelector)
                        .data("invokedOn", $(e.target))
                        .show()
                        .css({
                            position: "absolute",
                            left: getLeftLocation(e),
                            top: getTopLocation(e)
                        });
                    //add click listener on menu
                    ContextMenuClickHandler();
                    e.preventDefault();
                    //return false;
                });

                // click handler for context menu
                function ContextMenuClickHandler() {
                    $(settings.menuSelector)
                        .off('click')
                        .on('click', function (e) {
                            $(this).hide();

                            //Old
                            //var $invokedOn = $(this).data("invokedOn");
                            //New
                            var $invokedOn = $(this).data("invokedOn").closest('tr').attr('title');
                            var $selectedMenu = $(e.target);

                            //Old
                            //var $selectedFileId = $(this).data("invokedOn").find('.subFolder').attr('id');
                            //New
                            var $selectedFileId = $(this).data("invokedOn").closest('tr').attr('id');

                            //Old
                            //var $selectedFileAmazonUrl = $(this).data("invokedOn").find('.subFolder').attr('href');
                            //Final
                            var $selectedFileAmazonUrl = $(this).data("invokedOn").closest('tr').find('a').attr('href');

                            alert($selectedFileId);
                            //alert("Context menu  " + $selectedFileAmazonUrl);
                            Attr.prototype.currentFolderOrFileId = $selectedFileId

                            settings.menuSelected.call($(this), $invokedOn, $selectedMenu, $selectedFileId, $selectedFileAmazonUrl);
                            e.preventDefault();

                        });
                }
                //make sure menu closes on any click
                $(document).click(function () {
                    $(settings.menuSelector).hide();
                });
            });

            function getLeftLocation(e) {
                var mouseWidth = e.pageX;
                var pageWidth = $(window).width();
                var menuWidth = $(settings.menuSelector).width();

                // opening menu would pass the side of the page
                if (mouseWidth + menuWidth > pageWidth &&
                    menuWidth < mouseWidth) {
                    return mouseWidth - menuWidth;
                }
                return mouseWidth;
            }

            function getTopLocation(e) {
                var mouseHeight = e.pageY;
                var pageHeight = $(window).height();
                var menuHeight = $(settings.menuSelector).height();

                // opening menu would pass the bottom of the page
                if (mouseHeight + menuHeight > pageHeight &&
                    menuHeight < mouseHeight) {
                    return mouseHeight - menuHeight;
                }
                return mouseHeight;
            }

        };
    })(jQuery, window);

    $("#datalist-table td").contextMenu({
        menuSelector: "#contextMenu",
        menuSelected: function (invokedOn, selectedMenu, selectedFileId, selectedFileAmazonUrl) {
            var val = selectedMenu.text();
            if (val.indexOf("pload") > -1) {
                $('#UploadFileModal').modal();
            }
            else if (val.indexOf("ename") > -1) {
                //alert('Rename ' + invokedOn);
                //var data = invokedOn.text();
                var arr = invokedOn.split('.');
                $('#txtRenameFile').val(arr[0]);
                $('#txtRenameFile').data('id', arr[1]);
                self.RightClickMenuModelBoxButtons(url);
                $('#RenameFileModal').modal();
            }
            else if (val.indexOf("ownload") > -1) {


                alert(selectedFileAmazonUrl);
                self.FileDownload(selectedFileAmazonUrl)
                //bootbox.confirm("Are you sure? You want to delete " + invokedOn.text() + " File?", function (result) {
                //    Example.show("Confirm result: " + result);
                //});
            }
            else if (val.indexOf("iew") > -1) {

                $(selectedFileAmazonUrl).gdocsViewer();
                //alert(selectedFileAmazonUrl);
                //$(selectedFileAmazonUrl).gdocsViewer();
                //alert($("#" + selectedFileId).html());
                //alert($("#" + selectedFileId).parent().html());
                //$("#" + selectedFileId).parent().find('a').attr("href").gdocsViewer();
                //$("#" + selectedFileId).trigger("click").attr("href").gdocsViewer();
                //$("#" + selectedFileId).click(function () {
                //    alert($(this).attr("href"));
                //   // $(this).attr("href").gdocsViewer();
                //});
            }
            else if (val.indexOf("elete") > -1) {
                //$('#deleteFileName').val(invokedOn.text());
                //alert(Attr.prototype.currentFolderOrFileId);
                //alert(Attr.prototype.isFolderOrFile);
                self.RightClickMenuModelBoxButtons(url);
                $('#DeleteFileModal').modal();
            }
            else if (val.indexOf("ile") > -1) {
                if (Attr.prototype.currentFolderOrFileId != 0) {
                    common.AjaxCall(url + "/_UndoDeletedFile", "folderOrFileId=" + Attr.prototype.currentFolderOrFileId + "&isFolderOrFile=" + Attr.prototype.isFolderOrFile,
                "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                "UndoFile_OnSuccess", "");
                }
            }

        }
    });
       
},