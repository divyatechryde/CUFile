﻿function DirectoryManager() {
}


Attr.prototype.isSubFolder = 0;
Attr.prototype.activeSubFolderId = "";// Use for ContainerMenuHTML or On SeeMoreFile Click
Attr.prototype.levelId = 0;
Attr.prototype.FolderId = 1;
Attr.prototype.skipRows = 0;
Attr.prototype.searchPageSize = 10;
Attr.prototype.currentFolderOrFileId = 1;
Attr.prototype.isFolderOrFile = "";
Attr.prototype.isDeleted = 0;
Attr.prototype.timerInProgress = "false";
// Send file link URL, Value set from Share File OnClick, And Also FileURL is set for direct download from contect menu download click
Attr.prototype.ShareFileURL = "";
Attr.prototype.FileURL = "";
Attr.prototype.ControllerPath = "";
Attr.prototype.ControllerPathUserFiles = "";
Attr.prototype.WebURL = "cufile-dev.elasticbeanstalk.com";// i know this wrong but i change it after test my code.
// Use in RightClickMenuModelBoxButtons
Attr.prototype.IsAlreadyBind = true;
Attr.prototype.CurrentState = "Home";
Attr.prototype.UserFileFolderPath = "";
Attr.prototype.CurrentPeerID = 0;

Attr.prototype.FileUrlForDownload = "";// Use in CheckBandwidthStatusOnDownloadFile().

var pageSize = 100;
var skipRowsVal = 100;

DirectoryManager.prototype = {

    /* DirectoryManager ready function */

    ReadyFunctions: function () {
        //$(".left-menu-link").tooltip();
        $(".btn-default").tooltip();
        //$(".btn-group span").tooltip();
        //Use For change file size into readable form.
        $(".file-size").each(function () {
            var size = $(this).text();
            if (size.match(/^\d+$/)) { $(this).filesize(); }
        });

        //$("#containerDatalist").find("a").tooltip('hide');
        //$("#loadingRecords").tooltip('hide');
        //$(document).mousedown(function (event) { $("#loadingRecords tr").css("background-color", "white"); });
    },

    /* DirectoryManager default settings. */
    DefaultSetting: function () {
        var self = this;
        self.TopMenuButtonSetting();
        $(".breadcrumb li:first").nextAll().remove();
        $("#loadingRecords").html("");
        Attr.prototype.skipRows = 0;
        // Use For RightClickMenu from GetDeletedFiles
        if (Attr.prototype.isDeleted == 1) {
            $('#contextMenu li').each(function () { $(this).addClass("hidden"); });
            $("#contextMenu li:nth-child(6)").removeClass("hidden");
            $("#contextMenu li:nth-child(7)").removeClass("hidden");
        } //End
        // Use For RightClickMenu from GetAllRecentFiles
        if (Attr.prototype.isDeleted == 2) {
            $('#contextMenu li').each(function () { $(this).addClass("hidden"); });
            $("#contextMenu li:nth-child(2)").removeClass("hidden");
            $("#contextMenu li:nth-child(4)").removeClass("hidden");
            $("#contextMenu li:nth-child(5)").removeClass("hidden");
        } //End       
        // Use For RightClickMenu from Get User Files
        if (Attr.prototype.isDeleted == 3) {
            $('#contextMenu li').each(function () { $(this).addClass("hidden"); });
            $("#contextMenu li:nth-child(3)").addClass("hidden");
            $("#contextMenu li:nth-child(4)").removeClass("hidden");
        }
    },

    /* DirectoryManager default settings. */
    DefaultSettingValues: function () {
        var self = this;
        self.TopMenuButtonSetting();
        // Use For RightClickMenu from ContainerMenuHome_click
        if (Attr.prototype.isDeleted == 0) {
            $('#contextMenu li').each(function () { $(this).removeClass("hidden"); });
            $("#contextMenu li:nth-child(6)").addClass("hidden");
            $("#contextMenu li:nth-child(7)").addClass("hidden");
        } //End 
            // its not done yet. i add it on 21 Sep 2015. Befor bakra Eid
        else if (Attr.prototype.isDeleted == 3) {
            $('#contextMenu li').each(function () { $(this).removeClass("hidden"); });
            $("#contextMenu li:nth-child(3)").addClass("hidden");
            $("#contextMenu li:nth-child(6)").addClass("hidden");
            $("#contextMenu li:nth-child(7)").addClass("hidden");
        } //End
        if (Attr.prototype.isSubFolder != 0) {
            Attr.prototype.isSubFolder = 0;
            Attr.prototype.activeSubFolderId = "";
            Attr.prototype.skipRows = 0;
            Attr.prototype.searchPageSize = 10;
        }
    },

    /* DirectoryManager default settings. */
    TopMenuButtonSetting: function () {
        if (Attr.prototype.CurrentState == "Home") {
            $('#lg-menu-Peers li a').each(function () { $(this).removeAttr("style"); });
            $('#topMenuButtons div button').each(function () { $(this).show(); });
            $("#btnHomeFiles").hide();
        }
        else if (Attr.prototype.CurrentState == "UserFiles") {
            $('#lg-menu-Peers li a').each(function () { $(this).removeAttr("style"); });
            $('#lg-menu-Peers li a[data-id=' + Attr.prototype.CurrentPeerID + ']').css({ "color": "#fff", "font-wight": "500 !important" });
            $('#topMenuButtons div button').each(function () { $(this).hide(); });
            $("#btnHomeFiles").show();
            $("#btnSetting").show();
        }
    },

    /* Container Get Paged Home click event. */
    Timer: function (url) {

        $("#hfTimerStatus").val("False");
        setInterval(function () {
            $("#hfTimer").val("1");
            if ($("#hfTimerStatus").val() == "False" && Attr.prototype.CurrentState == "Home") {
                $("#hfTimerStatus").val("True");
                //console.log("levelId " + Attr.prototype.levelId);
                //console.log("FolderId " + Attr.prototype.FolderId);
                common.AjaxCall(url + "/_GetFolderAndFilesByTimer", "{'levelId':'" + Attr.prototype.levelId + "','folderId':'" + Attr.prototype.FolderId + "'}",
                                                  "POST", "html", "application/json; charset=utf-8",
                                                  "DirectoryManager_GetFolderAndFilesByTimer_OnSuccess", "DirectoryManager_GetFolderAndFilesByTimer_OnError");
            }
        }, 10000);

        //$("#GetFiles").click(function (event) {
        //    common.AjaxCall(url + "/_GetFolderAndFilesByTimer", "{'levelId':'" + Attr.prototype.levelId + "','folderId':'" + Attr.prototype.FolderId + "'}",
        //                                          "POST", "html", "application/json; charset=utf-8",
        //                                          "DirectoryManager_GetFolderAndFilesByTimer_OnSuccess", "DirectoryManager_GetFolderAndFilesByTimer_OnError");
        //});

    },

    /* Container Get Paged Home click event. */
    GetPaged: function (url) {
        // Added on 8 August 2015 By mee. Work on download file
        Attr.prototype.ControllerPath = url;//End
        $('#loadingRecords').on("click", ".seeMore_Home", function () {
            var common = new Common();
            Attr.prototype.skipRows += skipRowsVal;
            common.AjaxCall(url + "/_ContainerDatalist_GetPaged", "pageSize=" + pageSize + "&skipRows=" + Attr.prototype.skipRows + "",
                                           "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                                           "DirectoryManager_GetPaged_OnSuccess", "");
        });
    },

    /* DirectoryManager default settings. */
    GetPaged_OnSeeMoreClick: function (url) {
        var common = new Common();
        Attr.prototype.skipRows += skipRowsVal;
        common.AjaxCall(url + "/_ContainerDatalist_GetPaged", "pageSize=" + pageSize + "&skipRows=" + Attr.prototype.skipRows + "",
                                       "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                                       "DirectoryManager_GetPaged_OnSuccess", "");
    },

    /* Container Menu Home click event. */
    ContainerMenuHome_click: function (url) {
        var self = this;
        var common = new Common();
        self.RightClickMenu(url);
        $(".breadcrumb li a").click(function () {
            var subFolderId = $(this).attr('id');
            Attr.prototype.isDeleted = 0;
            Attr.prototype.FolderId = 1;
            Attr.prototype.levelId = 0; // Qasim 24-Nov-2015
            Attr.prototype.CurrentState = "Home";
            self.DefaultSettingValues();
            if (subFolderId == 0) {
                if (!$(this).hasClass("userFileFolder")) {
                    common.AjaxCall(url + "/_ContainerDatalist", "",
                         "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                         "DirectoryManager_GetPagedHome_OnSuccess", "");
                    $(".breadcrumb li a").removeClass("active");
                    self.ContainerMenuNavigationHandler("Home");
                    $(".breadcrumb li:first").nextAll().remove();
                }
                else {
                    Attr.prototype.UserFileFolderPath = $(this).data('folderpath');
                    self.FetchAllUserFiles(Attr.prototype.ControllerPathUserFiles);
                    $(".breadcrumb li a").removeClass("active");
                    self.ContainerMenuUserFilesNavigationHandler("Home");
                    $(".breadcrumb li:first").nextAll().remove();
                }
            }
        });
    },

    /* Click Event for Container Menu newly generated links. */
    ContainerMenuNav_click: function (url) {
        var common = new Common();
        var self = this;
        self.RightClickMenu(url);

        $(".breadcrumb li a").click(function (e) {
            if ($(this).hasClass("unclickable")) {
                e.preventDefault();
            } else {
                $(this).addClass("unclickable");
                //Your code continues here
                //Remember to remove the unclickable class when you want it to run again.
                self.DefaultSettingValues();
                $("#datalist-table").off("click", '*[data-toggle="lightbox"]');
                var subFolderId = $(this).attr('id');
                var subFolderName = $(this).attr('data-filetitle');
                //var subFolderLevelId = $(this).data("id"); Qasim 24-Nov-2015
                var subFolderLevelId = $(this).attr("data-id");

                Attr.prototype.levelId = subFolderLevelId; // Qasim 24-Nov-2015
                Attr.prototype.FolderId = subFolderId; // Qasim 24-Nov-2015

                if (subFolderId > 0) {
                    if (!$(this).hasClass("userFileFolder")) {
                        common.AjaxCall(url + "/_SubFolderContainerDatalist", "subFolderId=" + subFolderId + "&subFolderLevelId=" + subFolderLevelId,
                              "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                              "DirectoryManager_GetSubFolderPaged_OnSuccess", "");
                        self.ContainerMenuSubFolder_HTML(subFolderId, subFolderName, subFolderLevelId);
                        self.ContainerMenuNavigationHandler("breadcrumb");
                    }
                        // Need this else after work on UserFiles. :(
                    else {
                        Attr.prototype.UserFileFolderPath = $(this).data('folderpath');
                        self.FetchAllUserFiles(Attr.prototype.ControllerPathUserFiles);
                        self.ContainerMenuUserFilesSubFolder_HTML(subFolderId, subFolderName, Attr.prototype.UserFileFolderPath);
                        self.ContainerMenuUserFilesNavigationHandler("breadcrumb");
                    }
                    $(this).addClass("active");
                    $(this).parent("li").nextAll().remove();
                }

            }
        });

        $(".dropdown-menu-container li a").click(function (e) {
            if ($(this).hasClass("unclickable")) {
                e.preventDefault();
            } else {
                $(this).addClass("unclickable");
                //Your code continues here
                //Remember to remove the unclickable class when you want it to run again.
                self.DefaultSettingValues();
                $("#datalist-table").off("click", '*[data-toggle="lightbox"]');
                var subFolderId = $(this).attr('id');
                var subFolderName = $(this).attr('data-filetitle');
                var subFolderLevelId = $(this).data("id");

                Attr.prototype.levelId = subFolderLevelId; // Qasim 24-Nov-2015
                Attr.prototype.FolderId = subFolderId; // Qasim 24-Nov-2015

                if (subFolderId > 0) {
                    if (!$(this).hasClass("userFileFolder")) {
                        common.AjaxCall(url + "/_SubFolderContainerDatalist", "subFolderId=" + subFolderId + "&subFolderLevelId=" + subFolderLevelId,
                              "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                              "DirectoryManager_GetSubFolderPaged_OnSuccess", "");
                        self.ContainerMenuSubFolder_HTML(subFolderId, subFolderName, subFolderLevelId);
                    }
                    else {
                        Attr.prototype.UserFileFolderPath = $(this).data('folderpath');
                        self.FetchAllUserFiles(Attr.prototype.ControllerPathUserFiles);
                        self.ContainerMenuUserFilesSubFolder_HTML(subFolderId, subFolderName, Attr.prototype.UserFileFolderPath);
                    }
                    $(this).addClass("active");
                    $(this).parent("li").nextAll().remove();
                }
            }
        });

        $(".btn-dropdown-menu-container").click(function (e) { $("#dropdown-menu-ui").removeAttr("style"); });
    },

    /* Click Event for Sub Folders links. */
    GetSubFolderPaged: function (url) {
        var self = this;
        self.RightClickMenu(url);
        $('#loadingRecords').on("click", ".subFolderClass", function (e) {
            if ($(this).hasClass("unclickable")) {
                e.preventDefault();
            } else {
                $(this).addClass("unclickable");
                var subFolderId = $(this).attr('id');
                var subFolderName = $("#" + subFolderId).attr('data-filetitle');
                //var subFolderLevelId = $(this).data("id"); Qasim 24-Nov-2015
                var subFolderLevelId = $(this).attr("data-id");
                Attr.prototype.levelId = subFolderLevelId;
                Attr.prototype.FolderId = subFolderId;
                self.DefaultSettingValues();
                //Your code continues here
                //Remember to remove the unclickable class when you want it to run again.
                //Adding New Code on 4-Sep-2015 while working on UserFile Sub Folder list.
                if (!$(this).hasClass("userFileFolder")) {
                    common.AjaxCall(url + "/_SubFolderContainerDatalist", "subFolderId=" + subFolderId + "&subFolderLevelId=" + subFolderLevelId,
                               "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                               "DirectoryManager_GetSubFolderPaged_OnSuccess", "");
                    self.ContainerMenuSubFolder_HTML(subFolderId, subFolderName, subFolderLevelId);
                    self.ContainerMenuNavigationHandler("SubFolder");
                }
                else {
                    Attr.prototype.UserFileFolderPath = $(this).data('folderpath');
                    self.FetchAllUserFiles(Attr.prototype.ControllerPathUserFiles);
                    self.ContainerMenuUserFilesSubFolder_HTML(subFolderId, $(this).data('filetitle'), Attr.prototype.UserFileFolderPath);
                    self.ContainerMenuUserFilesNavigationHandler("SubFolder");
                }
            }
        });

    },

    /* Create HTML for Container Menu links. */
    ContainerMenuSubFolder_HTML: function (subFolderId, subFolderName, subFolderLevelId) {
        Attr.prototype.isSubFolder = 1;
        Attr.prototype.activeSubFolderId = subFolderId;
        $("#datalist-table").off("click", '*[data-toggle="lightbox"]');
        var newSubFolderLink = '<li><a id="' + subFolderId + '" data-filetitle="' + subFolderName + '" data-id="' + subFolderLevelId + '"  href="#"  class="active unclickable">' + subFolderName + '</a></li>'
        $(".breadcrumb li:last").after(newSubFolderLink);
        $("#dropdown-menu-ui").removeAttr("style");
    },

    ContainerMenuNavigationHandler: function (callBy) {
        var drpliCount = "0";
        Attr.prototype.liCount = $(".breadcrumb li").length;
        $("#dropdown-menu-ui").removeAttr("style");
        if (callBy == "SubFolder") {
            if (Attr.prototype.liCount > 2) {
                $(".btn-dropdown-menu-container").removeClass("hidden");
                $(".breadcrumb li:first").appendTo(".dropdown-menu-container:last");
            }
        }
        else if (callBy == "Home") {
            $(".btn-dropdown-menu-container").addClass("hidden");
            $(".dropdown-menu-container li:first").prependTo(".breadcrumb");
            $(".dropdown-menu-container").html(" ");
            document.getElementById("dropdown-menu-ui").removeAttribute("style");
            $("#dropdown-menu-ui").removeAttr("style");
        }
        else {
            drpliCount = $(".dropdown-menu-container li").length;
            $(".dropdown-menu-container li:last").prependTo(".breadcrumb", function () {
                $("#dropdown-menu-ui").removeAttr("style");
            });
            if (drpliCount == "1") {
                $(".btn-dropdown-menu-container").addClass("hidden");
            }
        }
        $("#dropdown-menu-ui").removeAttr("style");
        $(".breadcrumb li a:not(:last)").removeClass("active unclickable");
    },

    /* Create HTML for Container Menu links in User files section. */
    ContainerMenuUserFilesSubFolder_HTML: function (subFolderId, subFolderName, folderPath) {
        Attr.prototype.isSubFolder = 1;
        Attr.prototype.activeSubFolderId = subFolderId;
        $("#datalist-table").off("click", '*[data-toggle="lightbox"]');
        //console.log("ContainerMenuUserFilesSubFolder_HTML Before : " + $(".breadcrumb li").length);
        var newSubFolderLink = '<li><a id="' + subFolderId + '" data-filetitle="' + subFolderName + '" data-folderpath="' + folderPath + '"  class="active unclickable hand userFileFolder">' + subFolderName + '</a></li>'
        $(".breadcrumb li:last").after(newSubFolderLink);
        //console.log("ContainerMenuUserFilesSubFolder_HTML After : " + $(".breadcrumb li").length);
        $("#dropdown-menu-ui").removeAttr("style");
    },

    ContainerMenuUserFilesNavigationHandler: function (callBy) {
        var drpliCount = "0";
        Attr.prototype.liCount = $(".breadcrumb li").length;
        $("#dropdown-menu-ui").removeAttr("style");
        if (callBy == "SubFolder") {
            if (Attr.prototype.liCount > 2) {
                $(".btn-dropdown-menu-container").removeClass("hidden");
                $(".breadcrumb li:first").appendTo(".dropdown-menu-container:last");
            }
        }
        else if (callBy == "Home") {
            $(".btn-dropdown-menu-container").addClass("hidden");
            $(".dropdown-menu-container li:first").prependTo(".breadcrumb");
            $(".dropdown-menu-container").html(" ");
            document.getElementById("dropdown-menu-ui").removeAttribute("style");
            $("#dropdown-menu-ui").removeAttr("style");
        }
        else {
            drpliCount = $(".dropdown-menu-container li").length;
            $(".dropdown-menu-container li:last").prependTo(".breadcrumb", function () {
                $("#dropdown-menu-ui").removeAttr("style");
            });
            if (drpliCount == "1") {
                $(".btn-dropdown-menu-container").addClass("hide");
            }
        }
        $("#dropdown-menu-ui").removeAttr("style");
        $(".breadcrumb li a:not(:last)").removeClass("active unclickable");
    },


    /* Create HTML for Container Menu links. */
    GetSubFolder_SeeMore: function (url) {
        var common = new Common();
        Attr.prototype.skipRows += skipRowsVal;
        common.AjaxCall(url + "/_SubFolderContainerDatalist_GetPaged", "subFolderId=" + Attr.prototype.activeSubFolderId + "&subFolderLevelId=" + Attr.prototype.levelId + "&pageSize=" + pageSize + "&skipRows=" + Attr.prototype.skipRows,
        "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
        "DirectoryManager_GetPaged_OnSuccess", "");
    },

    /* Get All recent files from left navigation See-More. */
    GetAllRecentFiles: function (url) {
        var common = new Common();
        var self = this;
        $('#sidebar').on("click", ".seeMore_RecentFiles", function () {
            getdata();
        });

        $('#sidebarxs').on("click", ".seeMore_RecentFiles", function () {
            getdata();
        });

        function getdata() {
            // i Add this on 7 Sep 2015
            self.MakeBreadcrumsToDefault(); // End
            common.DefaultSearchSetting("new");
            Attr.prototype.isDeleted = 2;
            self.DefaultSetting();
            common.AjaxCall(url + "/_GetAllRecentFilesContainerDatalist", "",
            "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
            "DirectoryManager_GetAllRecentFiles_OnSuccess", "");

            $(".div-previewfile").fadeOut(1000, function () {
                $(".div-datalist").fadeIn(100);
            });
        }

        $('#div-recent-file-status').on("click", "a.on", function () {
            common.AjaxCall(url + "/AllPeersRecentFolderSyncON", "",
               "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
               "RecentFileSyncON_OnSuccess", "RecentFileSyncON_OnError");
        });

        $('#div-recent-file-status').on("click", "a.off", function () {
            common.AjaxCall(url + "/AllPeersRecentFolderSyncOff", "",
               "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
               "RecentFileSyncOff_OnSuccess", "RecentFileSyncOff_OnError");
        });


    },

    /* Get All Deleted Files */
    GetDeletedFiles: function (url) {
        var common = new Common();
        var self = this;
        $('#topMenuButtons').on("click", "#btnDeletFiles", function () {
            common.DefaultSearchSetting("new");
            Attr.prototype.isDeleted = 1;
            self.DefaultSetting();
            common.AjaxCall(url + "/_GetDeletedFilesDatalist", "",
            "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
            "DirectoryManager_GetDeletedFiles_OnSuccess", "");
        });
    },

    /* Use for sorting */
    SortByFileName: function () {
        $("p").click(function (e) {
            var $sort = this;
            var icon = $(this).find("b");
            var $list = $('#loadingRecords');
            var $listLi = $('tr', $list);
            $listLi.sort(function (a, b) {
                var keyA = $(a).attr("data-filetitle");
                var keyB = $(b).attr("data-filetitle");
                if ($($sort).hasClass('asc')) {
                    icon.removeClass('caretUp'); icon.addClass('caretDown');
                    return (keyA > keyB) ? 1 : 0;
                } else {
                    icon.removeClass('caretDown'); icon.addClass('caretUp');
                    return (keyA < keyB) ? 1 : 0;
                }
            });
            $($sort).toggleClass("asc");
            $.each($listLi, function (index, row) {
                $list.append(row);
            });
            e.preventDefault();
        });
    },

    /* Left Navigation bar */
    LeftNav: function () {
        var nav_val = 0;
        $('#nav-left').click(function () {
            if (nav_val == 0) {
                $('#containerMenu').removeClass('col-xs-12');
                $('#containerMenu').addClass('col-xs-8');
                nav_val = 1;
            }
            else {
                $('#containerMenu').addClass('col-xs-12');
                $('#containerMenu').removeClass('col-xs-8');
                nav_val = 0;
            }
        });
    },

    /* Use for searching  */
    Search: function (url) {
        var self = this;
        var common = new Common();
        $("#serachTextBox").keyup(function () {
            delay(function () {
                $("#datalist-table").off("click", '*[data-toggle="lightbox"]');
                common.DefaultSearchSetting("new");
                var searchText = $("#serachTextBox").val();
                if (searchText != '') {
                    self.DefaultSetting();
                    common.AjaxCall(url + "/_SearchContainer", JSON.stringify({ searchText: searchText }),
                     "POST", "json", "application/json",
                     "GetSearch_Opration", "");
                    $(".breadcrumb li a").removeClass("active");
                    self.ContainerMenuNavigationHandler("Home");
                    $(".breadcrumb li:first").nextAll().remove();
                }
            }, 1000);
        });
        $("#serachTextBox").keydown(function (event) {
            var searchText = $("#serachTextBox").val();
            var wordsLength = searchText.length;
            if (wordsLength == "0" || wordsLength == "1") {
                if (event.which == 8 || event.which == 46) {
                    //Remove it if any error. I add this on 7-Sep-2015
                    $(".breadcrumb li:first a").removeClass("userFileFolder");
                    $(".breadcrumb li:first a").text("Home");
                    Attr.prototype.CurrentState = "Home";
                    //End // Also i add this on GetSearch_Opration
                    $(".breadcrumb li:first a").trigger("click");
                }
            }
        });
        $("#btnSearch").click(function () {
            $("#datalist-table").off("click", '*[data-toggle="lightbox"]');
            common.DefaultSearchSetting("new");
            var searchText = $("#serachTextBox").val();
            if (searchText != '') {
                self.DefaultSetting();
                common.AjaxCall(url + "/_SearchContainer", JSON.stringify({ searchText: searchText }),
                 "POST", "json", "application/json",
                 "GetSearch_Opration", "");
            }
        });
        var delay = (function () {
            var timer = 0;
            return function (callback, ms) {
                clearTimeout(timer);
                timer = setTimeout(callback, ms);
            };
        })();
    },

    /* Use for top menu butoon  */
    TopMenuButtons: function (url) {
        $('#topMenuButtons').on("click", "#btnUpload", function () { $('#UploadFileModal').modal(); });

        // I add this for home button from top menu button. 25-Aug-2015
        var self = this;
        var common = new Common();
        self.RightClickMenu(url);
        $('#topMenuButtons').on("click", "#btnHomeFiles", function () {
            self.MakeBreadcrumsToDefault();
            Attr.prototype.isDeleted = 0;
            Attr.prototype.FolderId = 1;
            self.DefaultSettingValues();
            common.AjaxCall(url + "/_ContainerDatalist", "",
                 "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                 "DirectoryManager_GetPagedHome_OnSuccess", "");
        });

    },

    /* Use for right click menu on data list.   */
    /* Some old code of that function is in jscommenteddata.js   */
    RightClickMenu: function (url) {
        var self = this;

        (function ($, window) {
            $.fn.contextMenu = function (settings) {
                //return this.each(function () {
                // Open context menu    
                var trId = '';
                $(this).on("contextmenu", function (e) {
                    // Mjy UserFiles jo faded the un per menu nahi chay tha, ic ly ya if use ki ha.
                    if ($(this).closest('tr').hasClass("userFileFolder")) { return true; }
                    if ($(this).closest('tr').hasClass("NoFileAvailable")) { return true; }// Qasim 25-Nov-2015
                    var trId = $(this).closest('tr').attr('id');
                    var IsRecent = $(this).closest('tr').data('isrecent');
                    //$("#loadingRecords tr[id='" + trId + "']").css("background-color", "#e0f5ff");
                    //open menu 
                    // Final                       
                    var className = e.target.parentElement.className;
                    Attr.prototype.isFolderOrFile = className;
                    $("#contextMenu li:nth-child(1)").addClass("hidden");
                    if (className == "File" || className.indexOf('File') > -1) {
                        //Added on 10 August 2015, Whilw working on Download File.
                        $("#contextMenu li:nth-child(4) a").attr("class", "contextMenuDownloadClick");
                        //$("#contextMenu li:nth-child(4) a").attr("href", url + "/DirectDownloadFile?FileId="); // Id set from on click of download after encrypt);
                        $("#contextMenu li:nth-child(4) a").data("id", trId);
                        var isRecent = $("#contextMenu li:nth-child(4) a").data("isrecent", IsRecent);
                        //console.log("Tr" + trId);
                        //console.log("contextMenu li:nth-child(4) " + $("#contextMenu li:nth-child(4) a").data("id"));
                        //End here
                        $("#contextMenu li:nth-child(2)").removeClass("hidden");
                        $("#contextMenu li:nth-child(2)").attr("style", "display: block !important; visibility: visible !important;");
                    }
                    if (className.indexOf('Folder') >= 0 || className.indexOf('Deleted') > -1) {
                        $("#contextMenu li:nth-child(2)").addClass("hidden");
                    }
                    $(settings.menuSelector)
                        .data("invokedOn", $(e.target))
                        .show()
                        .css({
                            position: "absolute",
                            left: getLeftLocation(e),
                            top: getTopLocation(e)
                        });
                    //add click listener on menu
                    ContextMenuClickHandler();
                    e.preventDefault();
                    //return false;
                });
                // click handler for context menu
                function ContextMenuClickHandler() {
                    $(settings.menuSelector)
                        .off('click')
                        .on('click', function (e) {
                            $(this).hide();
                            var $invokedOn = $(this).data("invokedOn").closest('tr').attr('data-filetitle');
                            var $selectedMenu = $(e.target);
                            var $selectedFileId = $(this).data("invokedOn").closest('tr').attr('id');
                            //var $selectedFileAmazonUrl = $(this).data("invokedOn").closest('tr').find('a:nth-child(1)').attr('href');
                            var $selectedFileAmazonUrl = $(this).data("invokedOn").closest('tr').find('a:nth-child(1)').attr('data-fileurl');
                            Attr.prototype.currentFolderOrFileId = $selectedFileId;
                            settings.menuSelected.call($(this), $invokedOn, $selectedMenu, $selectedFileId, $selectedFileAmazonUrl);
                            e.preventDefault();
                        });
                }
                //make sure menu closes on any click
                $(document).click(function () { $(settings.menuSelector).hide(); });
                //});

                function getLeftLocation(e) {
                    var mouseWidth = e.pageX;
                    var pageWidth = $(window).width();
                    var menuWidth = $(settings.menuSelector).width();
                    // opening menu would pass the side of the page
                    if (mouseWidth + menuWidth > pageWidth &&
                        menuWidth < mouseWidth) {
                        return mouseWidth - menuWidth;
                    }
                    return mouseWidth;
                }
                function getTopLocation(e) {
                    var mouseHeight = e.pageY;
                    var pageHeight = $(window).height();
                    var menuHeight = $(settings.menuSelector).height();
                    // opening menu would pass the bottom of the page
                    if (mouseHeight + menuHeight > pageHeight &&
                        menuHeight < mouseHeight) {
                        return mouseHeight - menuHeight;
                    }
                    return mouseHeight;
                }
            };
        })(jQuery, window);

        $("#datalist-table td").contextMenu({
            menuSelector: "#contextMenu",
            menuSelected: function (invokedOn, selectedMenu, selectedFileId, selectedFileAmazonUrl) {
                var val = selectedMenu.text();
                if (val.indexOf("pload") > -1) {
                    $('#UploadFileModal').modal();
                }
                else if (val.indexOf("ename") > -1) {
                    var arr1 = invokedOn.split('.');
                    var pieces = invokedOn.split(/[\s,]+/);
                    // var output = invokedOn.split(/[, ]+/).pop();
                    var arr = invokedOn.substring(0, invokedOn.lastIndexOf("."));
                    $('#txtRenameFile').val(arr);
                    $('#txtRenameFile').data('id', arr1[arr1.length - 1]);
                    if (Attr.prototype.IsAlreadyBind)
                        self.RightClickMenuModelBoxButtons(url);
                    $('#RenameFileModal').modal();
                }
                else if (val.indexOf("ownload") > -1) {
                    // I change this while working on download file on right click menu click.
                    var fileId = $("#contextMenu li:nth-child(4) a").data("id");
                    var isRecent = $("#contextMenu li:nth-child(4) a").data("isrecent");
                    //console.log("fileId " + fileId);
                    //$(".contextMenuDownloadClick").data("id"); // This not work in Ie so i change with it.
                    common.AjaxCall(Attr.prototype.ControllerPath + "/GetEncryptCusFileIdAndUserID", "fileID=" + fileId + "&isRecent=" + isRecent,
                       "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                       "GetEncryptCusFileIdAndUserIDByContextMenu_OnSuccess", "GetEncryptCusFileIdAndUserIDByContextMenu_OnError");
                }
                else if (val.indexOf("iew") > -1) {
                    //var fileExtension = $('#' + selectedFileId).find('span.FileExtention').data('id');
                    //if ((/\.(gif|jpg|jpeg|tiff|png)$/i).test(fileExtension)) {
                    //    $("#" + selectedFileId + " td:nth-child(2)").find('a').ekkoLightbox();
                    //}
                    //else if ((/\.(pdf|docx|doc|xlsx|xls|txt|ppt|pptx|psd|css|js|php|cs|cshtml|html|ashx|asax|config|aspx|aspx.cs|htm)$/i).test(fileExtension)) {
                    //    var href = "https://docs.google.com/viewer?embedded=true&url=" + selectedFileAmazonUrl;
                    //    $('#framedoc').attr('src', href);
                    //    $('#FileFileViewerrModel').modal();
                    //}

                    // New Work for show image.
                    //$("#" + selectedFileId).click(function (event) {
                    var $elm = $("#" + selectedFileId);
                    //alert($elm);
                    if ($elm.find(".File").hasClass("imgFile")) {
                        var imgPath = $elm.find(".File").attr("data-fileurl");
                        var d1 = Date.parse($elm.find(".timeago").attr("data-time"));
                        //var d1 = Date.parse($elm.find(".timeago").html());

                        $("#p-fileDate").text(d1.toString('MMMM dd, yyyy'));
                        $("#p-fileSize").text($elm.find(".file-size").html());
                        $("#p-fileName").text($(this).data("filetitle"));
                        $(".p-fileShare").attr("onclick", $elm.find(".i-share").attr("onclick"));
                        $(".p-fileDownload").attr("onclick", $elm.find(".i-download").attr("onclick"));
                        $(".p-fileDelete").attr("onclick", $elm.find(".i-delete").attr("onclick"));

                        //alert(imgPath);
                        $("#img-Preview").attr("src", imgPath);
                        $('#img-Preview').show();
                        $('#img-Preview').imgPreload();
                        $(".div-datalist").fadeOut(1000, function () {
                            $(".div-previewfile").fadeIn(100);
                        });
                    } else if ($elm.find(".File").hasClass("noPreviewFile")) {
                        //var imgPath = $elm.find(".File").attr("data-fileurl");
                        var d1 = Date.parse($elm.find(".timeago").attr("data-time"));
                        //var d1 = Date.parse($elm.find(".timeago").html());
                        $("#p-fileDate").text(d1.toString('MMMM dd, yyyy'));
                        $("#p-fileSize").text($elm.find(".file-size").html());
                        $("#p-fileName").text($(this).data("filetitle"));
                        $(".p-fileShare").attr("onclick", $elm.find(".i-share").attr("onclick"));
                        $(".p-fileDownload").attr("onclick", $elm.find(".i-download").attr("onclick"));
                        $(".p-fileDelete").attr("onclick", $elm.find(".i-delete").attr("onclick"));

                        $("#no-preview-available").show();
                        $("#downloadFile").attr("onclick", $elm.find(".i-download").attr("onclick"));
                        $('#img-Preview').hide();
                        $(".div-datalist").fadeOut(1000, function () {
                            $(".div-previewfile").fadeIn(100);
                        });

                    }
                    //});

                    //$('.noPreviewFile').click(function (event) {
                    //    var $elm = $(this).closest(".tr-data-row");
                    //    var imgPath = $(this).data("fileurl");
                    //    var d1 = Date.parse($elm.find(".timeago").html());
                    //    var call = $(this).attr("onclick");

                    //    $("#p-fileDate").text(d1.toString('MMMM dd, yyyy'));
                    //    $("#p-fileSize").text($elm.find(".file-size").html());
                    //    $("#p-fileName").text($(this).data("filetitle"));
                    //    $(".p-fileShare").attr("onclick", $elm.find(".i-share").attr("onclick"));
                    //    $(".p-fileDownload").attr("href", $elm.find(".i-download").attr("href"));
                    //    $(".p-fileDelete").attr("onclick", $elm.find(".i-delete").attr("onclick"));

                    //    $("#no-preview-available").show();
                    //    $("#downloadFile").attr("href", $elm.find(".i-download").attr("href"));
                    //    $('#img-Preview').hide();
                    //    $(".div-datalist").fadeOut(1000, function () {
                    //        $(".div-previewfile").fadeIn(100);
                    //    });
                    //});

                }
                else if (val.indexOf("elete") > -1) {
                    if (Attr.prototype.IsAlreadyBind)
                        self.RightClickMenuModelBoxButtons(url);
                    $('#DeleteFileModal').modal();
                }
                else if (val.indexOf("ile") > -1) {
                    if (Attr.prototype.currentFolderOrFileId != 0) {
                        common.AjaxCall(url + "/_UndoDeletedFile", "folderOrFileId=" + Attr.prototype.currentFolderOrFileId + "&isFolderOrFile=" + Attr.prototype.isFolderOrFile,
                    "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8", "UndoFile_OnSuccess", "UndoFile_OnError");
                    }
                }
            }
        });

    },

    // Modelbox Buttons Events
    RightClickMenuModelBoxButtons: function (url) {
        Attr.prototype.IsAlreadyBind = false;
        // Rename File Modelbox Button
        $('#RenameFileModal').on("click", "#btnSaveRenameFile", function (e) {
            if ($('#txtRenameFile').val() == '') {
                $(".alert-danger").removeClass("hidden");
                window.setTimeout(function () { $(".alert-danger").addClass("hidden"); }, 2000);
            }
            else {
                var val = '';
                // Folder id is undefined
                if ($('#txtRenameFile').data('id') === undefined) {
                    val = $('#txtRenameFile').val();
                }
                else {
                    val = $('#txtRenameFile').val() + "." + $('#txtRenameFile').data('id');
                }
                common.AjaxCall(url + "/_RenameFile", "folderOrFileId=" + Attr.prototype.currentFolderOrFileId + "&folderOrFileName=" + val + "&isFolderOrFile=" + Attr.prototype.isFolderOrFile,
            "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
            "RenameFile_OnSuccess", "RenameFile_OnError");
            }
        });

        // Delete File Model box yes button.
        $('#DeleteFileModal').on("click", "#btnYesDeleteFile", function (e) {
            e.preventDefault();
            if (Attr.prototype.currentFolderOrFileId != 0) {
                if (Attr.prototype.isDeleted == 2) {
                    Attr.prototype.isFolderOrFile = "Recent";
                }
                common.AjaxCall(url + "/_DeleteFiles", "folderOrFileId=" + Attr.prototype.currentFolderOrFileId + "&isFolderOrFile=" + Attr.prototype.isFolderOrFile,
               "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
               "DeleteFile_OnSuccess", "DeleteFile_OnError");
            }
            //e.preventDefault();
        });

    },

    // Browser Detection For different css
    BrowserDetectionForCss: function () {
        if (BrowserDetection() == "safari")
        { $("#btnSearchMenu").css("margin-left", "-4px !important"); }
        function BrowserDetection() {
            if (navigator.userAgent.search("MSIE") >= 0) { }
            else if (navigator.userAgent.search("Chrome") >= 0) { }
            else if (navigator.userAgent.search("Firefox") >= 0) { }
            else if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
                return "safari";
            }
            else if (navigator.userAgent.search("Opera") >= 0) { }
        }
    },

    // Use For image viewer
    imageViewer: function () {
        //$("#datalist-table").on('click', '*[data-toggle="lightbox"]', function (event) {
        //    event.preventDefault();
        //    return $(this).ekkoLightbox({
        //        onShown: function () {
        //            if (window.console) { //return console.log('imageViewer');
        //            }
        //        },
        //        onNavigate: function (direction, itemIndex) {
        //            if (window.console) {
        //                return console.log('Navigating ' + direction + '. Current item: ' + itemIndex);
        //            }
        //        }
        //    });
        //});


        // New Work for show image.
        $('.imgFile').click(function (event) {
            var $elm = $(this).closest("tr.File");
            var imgPath = $(this).data("fileurl");
            var d1 = Date.parse($elm.find(".timeago").attr("data-time"));
            //var d1 = Date.parse($elm.find(".timeago").html());
            var call = $(this).attr("onclick");

            $("#p-fileDate").text(d1.toString('MMMM dd, yyyy'));
            $("#p-fileSize").text($elm.find(".file-size").html());
            $("#p-fileName").text($(this).data("filetitle"));
            $(".p-fileShare").attr("onclick", $elm.find(".i-share").attr("onclick"));
            $(".p-fileDownload").attr("onclick", $elm.find(".i-download").attr("onclick"));
            $(".p-fileDelete").attr("onclick", $elm.find(".i-delete").attr("onclick"));

            $("#img-Preview").attr("src", imgPath);
            $('#img-Preview').show();
            //alert("show image pree");
            $('#img-Preview').imgPreload();
            $(".div-datalist").fadeOut(1000, function () {
                $(".div-previewfile").fadeIn(100);
            });
        });

        $('.noPreviewFile').click(function (event) {
            var $elm = $(this).closest("tr.File");
            var imgPath = $(this).data("fileurl");
            var d1 = Date.parse($elm.find(".timeago").attr("data-time"));
            //var d1 = Date.parse($elm.find(".timeago").html());
            var call = $(this).attr("onclick");

            $("#p-fileDate").text(d1.toString('MMMM dd, yyyy'));
            $("#p-fileSize").text($elm.find(".file-size").html());
            $("#p-fileName").text($(this).data("filetitle"));
            $(".p-fileShare").attr("onclick", $elm.find(".i-share").attr("onclick"));
            $(".p-fileDownload").attr("onclick", $elm.find(".i-download").attr("onclick"));
            $(".p-fileDelete").attr("onclick", $elm.find(".i-delete").attr("onclick"));

            $("#no-preview-available").show();
            $("#downloadFile").attr("onclick", $elm.find(".i-download").attr("onclick"));
            $('#img-Preview').hide();
            //alert("hide image pree");
            $(".div-datalist").fadeOut(1000, function () {
                $(".div-previewfile").fadeIn(100);
            });
        });
    },

    DeleteFileFolderWithButton: function (id, type) {
        bootbox.dialog({
            message: "Are you sure you want to delete this " + type.toLowerCase() + "?",
            title: "Delete " + type,
            buttons: {
                success: {
                    label: "No",
                    className: "btn-default",
                    callback: function () { }
                },
                danger: {
                    label: "Yes",
                    className: "btn-primary",
                    callback: function () {
                        if (Attr.prototype.currentFolderOrFileId != 0) {
                            if (Attr.prototype.isDeleted == 2) {
                                Attr.prototype.isFolderOrFile = "Recent";
                            }
                            common.AjaxCall("/DirectoryManager/_DeleteFiles", "folderOrFileId=" + id + "&isFolderOrFile=" + type,
                           "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                           "DeleteFile_OnSuccess", "");
                        }
                    }
                }
            }
        });
    },

    // New Work Start from here
    /* Get Social Contacts for Gmail, Yahoo and Outlook... */
    // Call from share file click event.
    EmailFileLink: function (fileID, isRecent) {
        if ($.trim(fileID) != '') {
            common.AjaxCall(Attr.prototype.ControllerPath + "/GetEncryptCusFileIdAndUserID", "fileID=" + fileID + "&isRecent=" + isRecent,
       "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
       "GetEncryptCusFileIdAndUserID_OnSuccess", "GetEncryptCusFileIdAndUserID_OnError");
        }

    },

    /* Call from GetEncryptCusFileIdAndUserID_OnSuccess,  */
    SetFileLinkInTextBox: function (val) {
        var self = this;
        Attr.prototype.ShareFileURL = Attr.prototype.WebURL + Attr.prototype.ControllerPath + "/DownloadFile?FileId=" + val;
        self.ShowFileLinkInTextBox();
    },

    /* Call from SetFileLinkInTextBox,  */
    ShowFileLinkInTextBox: function () {
        $("#txt-Message").val('');
        $('.sendShareFile').attr("disabled", false);
        $("#searchSocialContact").val('');
        $("#txt-sharelink").val(Attr.prototype.ShareFileURL);
        $("#mySocialModal").modal('toggle');
    },

    /* Use for set URL of while download file on right click,  */
    SetFileDownloadByContextMenu: function (val) {
        if ($.browser.webkit) {
            Attr.prototype.FileURL = Attr.prototype.ControllerPath + "/DirectDownloadFile?FileId=" + val + "&isRecent=False";
        }
        else {
            Attr.prototype.FileURL = Attr.prototype.ControllerPath + "/DirectDownloadFile?FileId=" + val + "&isRecent=False";
        }
    },

    /* Call from home index after model shown event,  */
    CallFileDownloadByContextMenu: function (val) {
        // This method is in jquree.download.js file.
        downloadFile(Attr.prototype.FileURL);
    },

    /* Call from home index after model shown event,  */
    GetSocialContacts: function (url) {
        var common = new Common();
        common.AjaxCall(url + "/_GetSocialContactsStatus", "",
        "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
        "GetSocialContacts_OnSuccess", "GetSocialContacts_OnError");
    },

    /* Use for disconnect from connected social networks. */
    GetSocialContactsForDisconnect: function (url) {
        // Call is same like "GetSocialContacts, main work in success message
        var common = new Common();
        common.AjaxCall(url + "/_GetSocialContactsStatus", "",
        "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
        "GetSocialContactsForDisconnect_OnSuccess", "GetSocialContactsForDisconnect_OnError");
    },

    GoogleCallForDisconnect: function (url) {
        $("#btnDisconnectGoogle").click(function (event) {
            event.preventDefault();
            common.AjaxCall(url + "/DisconnectGoogle", "", "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8", "Disconnect_OnSuccess", "Disconnect_OnError");
        });
    },

    YahooCallForDisconnect: function (url) {
        $("#btnDisconnectYahoo").click(function (event) {
            event.preventDefault();
            common.AjaxCall(url + "/DisconnectYahoo", "", "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8", "Disconnect_OnSuccess", "Disconnect_OnError");
        });
    },

    OutlookCallForDisconnect: function (url) {
        $("#btnDisconnectOutlook").click(function (event) {
            event.preventDefault();
            common.AjaxCall(url + "/DisconnectOutlook", "", "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8", "Disconnect_OnSuccess", "Disconnect_OnError");
        });
    },

    SendShareFileEmail: function (url) {
        var common = new Common();
        $(".sendShareFile").click(function (event) {
            event.preventDefault();
            var msg = "";
            var EmailRegEx = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i

            var sharelink = $.trim($("#txt-sharelink").val());
            var socialContact = $.trim($("#searchSocialContact").val());
            var message = $.trim($("#txt-Message").val());

            //If last character is "," remove it
            socialContact = removeLastCh(socialContact);
            var emails = socialContact.split(",");

            if (socialContact == "" || socialContact == null) {
                $("input[id$='searchSocialContact']").addClass('inputError');
                $("span[id$='span_searchSocialContact']").text('Please enter email');
                msg += "Please enter email";
            }
            try {
                emails.forEach(function (email) {
                    if (!EmailRegEx.test(email)) {
                        $("input[id$='searchSocialContact']").addClass('inputError');
                        $("span[id$='span_searchSocialContact']").text('Please enter valid email address.');
                        msg += "Please enter a valid email address.";
                        throw "Ex";
                    }
                    else {
                        $("input[id$='searchSocialContact']").removeClass('inputError');
                        $("span[id$='span_searchSocialContact']").text('');
                    }
                });

            }
            catch (e) {
                console.log("C:E");
            }

            // Share Link
            if (sharelink == "" || sharelink == null) {
                $("input[id$='txt-sharelink']").addClass('inputError');
                $("span[id$='span_sharelink']").text('Please add share link.');
                msg += "Please add share link.";
            }
            else {
                $("input[id$='txt-sharelink']").removeClass('inputError');
                $("span[id$='span_sharelink']").text('');
            }
            if (msg == "") {
                $('.sendShareFile').attr("disabled", true);
                common.AjaxCall(url + "/_SendShareFileEmail", "toEmail=" + socialContact + "&fileLink=" + sharelink + "&message=" + message,
                         "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8", "SendShareFileEmail_OnSuccess", "SendShareFileEmail_OnError");
            }
        });

        function removeLastCh(myEmail) {
            if (myEmail.substring(myEmail.length - 1) == ",") {
                myEmail = myEmail.substring(0, myEmail.length - 1);
            }
            return myEmail;
        }
    },

    /* Use for apply style on active connected social networks. */
    ActiveButtonsAfterFetch: function (xml) {

        parseXmlForStyle(xml);

        function parseXmlForStyle(xml) {
            defaultStyle();
            checkStatus(xml, "Google");
            checkStatus(xml, "Yahoo");
            checkStatus(xml, "Outlook");
        }

        function defaultStyle() {
            $("#btnGoogle").removeClass("fa-google-color");
            $("#btnYahoo").removeClass("fa-yahoo-color");
            $("#btnWindows").removeClass("fa-windows-color");
        }

        function checkStatus(xml, root) {
            $(xml).find(root).each(function () {
                $(this).find("Status").each(function () {
                    var status = $(this).attr("label");
                    if (status == "True" && root == "Google")
                        $("#btnGoogle").addClass("fa-google-color");
                    else if (status == "True" && root == "Yahoo")
                        $("#btnYahoo").addClass("fa-yahoo-color");
                    else if (status == "True" && root == "Outlook")
                        $("#btnWindows").addClass("fa-windows-color");
                });
            });
        }
    },

    // Just for testing. 
    GetShareFileURL: function (url) {
        var common = new Common();
        $(".sendGetShareFileURL").click(function (event) {
            common.AjaxCall(url + "/GetEncryptCusFileIdAndUserID", "",
                         "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8", "GetShareFileURL_OnSuccess", "GetShareFileURL_OnError");
        });
    },

    /* Get All User Files. */
    GetAllUserFiles: function (url) {
        var self = this;
        $('#sidebar').on("click", ".peerClass", function () {
            getdata(this);
        });

        $('#sidebarxs').on("click", ".peerClass", function () {
            getdata();
        });

        function getdata(elm) {
            //console.log('html ' + $(elm).parent().html());
            //console.log('Id ' + $(elm).attr("data-id"));
            Attr.prototype.CurrentPeerID = $(elm).attr("data-id");
            self.MakeBreadcrumsToDefault();
            // For UserFile need to update these two..
            $(".breadcrumb li:first a").addClass("userFileFolder");
            $(".breadcrumb li:first a").text("Userfiles"); //End
            //For First Call UserFileFolderPath is null.
            Attr.prototype.UserFileFolderPath = "";
            self.FetchAllUserFiles(url);

            $(".div-previewfile").fadeOut(1000, function () {
                $(".div-datalist").fadeIn(100);
            });
        }

    },

    /* Call From GetAllUserFiles and some other also.Ctrl Find. */
    FetchAllUserFiles: function (url) {
        var self = this;
        var common = new Common();
        Attr.prototype.ControllerPathUserFiles = url;
        Attr.prototype.CurrentState = "UserFiles";
        //common.DefaultSearchSetting("new");// I Commented It on 8 Sep 2015 Because of this UserFile Menu nahi cal raha tha. :P :P :P
        Attr.prototype.isDeleted = 3;
        //self.DefaultSetting();// I Commented It on 8 Sep 2015 Because of this UserFile Menu nahi cal raha tha. :P :P :P
        self.TopMenuButtonSetting();// I Add It on 8 Sep 2015 Because left meun style nahi woprk kr raha tha.
        // Null or Empty Folder path because first time no foldername or path exists.
        common.AjaxCall(Attr.prototype.ControllerPathUserFiles + "/_GetAllUserFilesContainerDatalist", "folderPath=" + Attr.prototype.UserFileFolderPath + "&peerID=" + Attr.prototype.CurrentPeerID,
        "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
        "DirectoryManager_GetAllUserFiles_OnSuccess", "DirectoryManager_GetAllErrorFiles_OnError");
    },


    /* Get All Share Files. */
    GetAllShareFiles: function (url) {
        var self = this;
        //self.RightClickMenu(url);
        $('#sidebar').on("click", ".shareFiles", function () {
            getdata();
        });

        $('#sidebarxs').on("click", ".shareFiles", function () {
            getdata();
        });

        function getdata() {
            self.MakeBreadcrumsToDefault();
            Attr.prototype.isDeleted = 0;
            Attr.prototype.FolderId = 1;
            self.DefaultSettingValues();
            self.FetchAllShareFiles(url);

            $(".div-previewfile").fadeOut(1000, function () {
                $(".div-datalist").fadeIn(100);
            });
        }
    },

    /* Call From GetAllShareFiles and some other also. Ctrl Find. */
    FetchAllShareFiles: function (url) {
        var self = this;
        var common = new Common();
        self.TopMenuButtonSetting();
        common.AjaxCall(url + "/_GetAllShareFilesContainerDatalist", "shareFolderID=1",
        "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
        "DirectoryManager_GetAllShareFiles_OnSuccess", "");
    },

    // Created On 7 Sep 2015
    MakeBreadcrumsToDefault: function () {
        var self = this;
        //if it is come from Home Section.
        $(".breadcrumb li a").removeClass("active");
        self.ContainerMenuNavigationHandler("Home");
        $(".breadcrumb li:first").nextAll().remove();
        //if it is come from UserFile Section.
        $(".breadcrumb li:first a").removeClass("userFileFolder");
        $(".breadcrumb li:first a").text("Home");
        Attr.prototype.CurrentState = "Home";        // End
    },

    // Create this method for all download file links. 6-Nov-2015
    CheckBandwidthStatusOnDownloadFile: function (fileID, isRecent, fileUrl) {
        var self = this;
        var common = new Common();
        Attr.prototype.FileUrlForDownload = fileUrl;
        if ($.trim(fileID) != '') {
            common.AjaxCallObj(Attr.prototype.ControllerPath + "/CheckBandwidthStatusOnDownloadFile", "fileID=" + fileID + "&isRecent=" + isRecent,
       "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
       "CheckBandwidthStatusOnDownloadFile_OnSuccess", "CheckBandwidthStatusOnDownloadFile_OnError", self);
        }

    },

    CheckBandwidthStatusOnDownloadFile_OnSuccess: function (data) {
        if (data == "True")
            window.location = Attr.prototype.FileUrlForDownload;
        else
            toastr.error("Current bandwidth limit exceeded.", "Error");
    },

    CheckBandwidthStatusOnDownloadFile_OnError: function (data) {
        //console.log(data);
        console.log("CheckBandwidthStatusOnDownloadFile_OnError ");
    },

}

