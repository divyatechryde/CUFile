﻿function AccountManager() {
}
Attr.prototype.url = "";
Attr.prototype.peerId = "";
AccountManager.prototype = {

    /* AccountManager ready function */
    ReadyFunctions: function () {
        $(".file-size").each(function () {
            var size = $(this).text();
            if (size.match(/^\d+$/)) { $(this).filesize(); }
        });
    },

    /* Use for left nav bar links  */
    LeftNavBar: function (url) {
        var self = this;
        Attr.prototype.url = url;
        var common = new Common();
        $('.sidebar-links').on("click", "a.accountDetail", function () {
            css(this);
            common.AjaxCallObj(url + "/_ContainerAccountDetail", "",
                 "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                 "AccountManager_GetAccountDetail_OnSuccess", "AccountManager_GetAccountDetail_OnError", self);
        });

        $('.sidebar-links').on("click", "a.connectedDevices", function () {
            css(this);
            common.AjaxCallObj(url + "/_ContainerConnectedDevicesDetail", "",
                 "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                 "AccountManager_GetConnectedDevicesDetail_OnSuccess", "AccountManager_GetConnectedDevicesDetail_OnError", self);
        });

        function css(obj) {
            $('.sidebar-links a').removeClass("a-active");
            $(obj).addClass("a-active");
        }

    },

    /* Call Get Account Detail OnSuccess */
    AccountManager_GetAccountDetail_OnSuccess: function (data) {
        var self = this;
        $('#DataContainer').html(data);
        self.ReadyFunctions();
    },

    /* Call Get Account Detail OnError */
    AccountManager_GetAccountDetail_OnError: function (data) {
        console.log("GetAccountDetail_OnError " + data);
        $('#DataContainer').html(data);
    },

    /* Call Get account connected devices OnSuccess */
    AccountManager_GetConnectedDevicesDetail_OnSuccess: function (data) {
        var self = this;
        $('#DataContainer').html(data);
        self.ReadyFunctions();
        self.ChangePeerStatus(Attr.prototype.url);
    },

    /* Call Get account connected devices OnError */
    AccountManager_GetConnectedDevicesDetail_OnError: function (data) {
        console.log("GetConnectedDevicesDetail_OnError " + data);
        $('#DataContainer').html(data);
    },



    /* Use for left nav bar links  */
    ChangePeerStatus: function (url) {
        var self = this;
        var common = new Common();
        $('.change-peer-status').on("click", "a.connect", function () {
            Attr.prototype.peerId = $(this).attr("data-peerid");
            common.AjaxCallObj(url + "/ConnectPeer", "peerID=" + $(this).attr("data-peerid") + "",
                 "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                 "AccountManager_ConnectPeerStatus_OnSuccess", "AccountManager_ConnectPeerStatus_OnError", self);
        });

        $('.change-peer-status').on("click", "a.disconnect", function () {
            Attr.prototype.peerId = $(this).attr("data-peerid");
            common.AjaxCallObj(url + "/DisconnectPeer", "peerID=" + $(this).attr("data-peerid")  + "",
                 "POST", "html", "application/x-www-form-urlencoded; charset=UTF-8",
                 "AccountManager_DisconnectPeerStatus_OnSuccess", "AccountManager_DisconnectPeerStatus_OnError", self);
        });

      
    },


    AccountManager_ConnectPeerStatus_OnSuccess: function (data) {
        console.log("AccountManager_ConnectPeerStatus_OnSuccess " + data);
        if (data) {
            $('#peerid-' + Attr.prototype.peerId).html("Disconnect");
            $('#peerid-' + Attr.prototype.peerId).removeClass("connect");
            $('#peerid-' + Attr.prototype.peerId).addClass("disconnect");
        }
    },

    /* Call Get Account Detail OnError */
    AccountManager_ConnectPeerStatus_OnError: function (data) {
        console.log("AccountManager_ConnectPeerStatus_OnError " + data);
       
    },

    /* Call Get account connected devices OnSuccess */
    AccountManager_DisconnectPeerStatus_OnSuccess: function (data) {
        console.log("AccountManager_DisconnectPeerStatus_OnSuccess " + data);
        if (data) {
            $('#peerid-' + Attr.prototype.peerId).html("Connect");
            $('#peerid-' + Attr.prototype.peerId).removeClass("disconnect");
            $('#peerid-' + Attr.prototype.peerId).addClass("connect");
        }
    },

    /* Call Get account connected devices OnError */
    AccountManager_DisconnectPeerStatus_OnError: function (data) {
        console.log("AccountManager_DisconnectPeerStatus_OnError " + data);

    },


}

