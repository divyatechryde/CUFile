﻿/*Side menu JS*/
$(document).ready(function () {
    //$('#progressBar').tipsy({ gravity: 'e', html: true, delayIn: 600 });
    //$('#progressBarLogo').tipsy({ gravity: 'w', html: true, delayIn: 600 });
    //$('#fixProgress').tipsy({ gravity: 'e', html: true, delayIn: 600 });
    //Declare the elements we are going to use as variables
    var sideMenu = $('#sideMenu');
    fixLogo = $('.divFixedLogo');


    //On Mouseover of the player, add the class 'playerhover' to '.player' and 'searchButtonHover' to '.searchButton'
    fixLogo.mouseover(
      function () {
         sideMenu.show("slide", { direction: "left" }, 1000);
      });

    sideMenu.mouseleave(
        function () {
          sideMenu.hide("slide", { direction: "left" }, 1000);
        }
        );


});

/*Date and time with logo*/

$(document).ready(function () {

    var d = new Date();
    var hourString;
    var amPm = "AM";
    var hourInt;
    if (d.getHours() > 11) {
        amPm = "PM"
        hourInt = (d.getHours() - 12);
    } else {
        amPm = "AM"
        hourInt = d.getHours();
    }


    var formattedTime = hourInt + ":" + d.getMinutes() + " " + amPm;
    //alert(formattedTime);

    var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];
    
    var formattedDate = monthNames[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
    //alert(formattedDate);
    $(".logoTxt").html("Hello its <br/>" + formattedTime + " on <br/>" + formattedDate);
});

